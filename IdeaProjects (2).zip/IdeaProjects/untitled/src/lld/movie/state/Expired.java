package lld.movie.state;

public class Expired {

    //session expired
    //release lock on seat and go to idle state
}
