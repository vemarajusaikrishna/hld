package lld.ratelimiter.decorator;

import java.net.http.HttpRequest;

public interface API {

    void processRequest(String userId, HttpRequest httpRequest);
}
