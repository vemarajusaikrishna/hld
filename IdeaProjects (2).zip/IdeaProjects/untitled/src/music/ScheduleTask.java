package music;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScheduleTask {



    public  int getMaximumTasks(int limit, List<Integer> primary, List<Integer> secondary) {

        int n = primary.size();
        List<Integer> diff = new ArrayList<>();

        for (int i = 0 ; i < n ;i++) {
             diff.add(limit-primary.get(i));
        }

        Collections.sort(diff,Collections.reverseOrder());
        Collections.sort(secondary,Collections.reverseOrder());

        int i =0;
        int j =0;
        int counter =0;

        while(i < n && j < n)
        {
            if(diff.get(i) < secondary.get(i))
            {
                j++;
            }
            else
            {
                i++;
                j++;
                counter++;

            }
        }

        return counter;


    }
}
