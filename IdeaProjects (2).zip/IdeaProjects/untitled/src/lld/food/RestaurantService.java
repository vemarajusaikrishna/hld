package lld.food;

import lld.food.model.Restaurant;
import lld.food.model.cuisine.Cuisine;

import java.util.List;

public class RestaurantService {

    public List<Restaurant> getRestaurantsByName(String restaurantName){
     return null;
    }

    public List<Restaurant> getByCuisine(String cuisineType){
         return null;
    }

    public List<Restaurant> getByFoodItem(String FoodItemName){
      return null;
    }

    public void addRestaurant(Restaurant restaurant){

    }
    public void removeRestaurant(int id){

    }

    public void updateMenu(int id, Cuisine cuisine,int foodItemId,float price){

    }
}
