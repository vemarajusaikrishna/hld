package snake.momento;

public class GameStateHistory {

    private GameStateMomento gameStateMomento;

    public GameStateMomento restoreGame() {
        return gameStateMomento;
    }

    public void saveGame(GameStateMomento gameStateMomento) {
        this.gameStateMomento = gameStateMomento;
    }
}
