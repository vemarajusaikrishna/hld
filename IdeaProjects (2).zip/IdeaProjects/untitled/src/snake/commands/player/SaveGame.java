package snake.commands.player;

import snake.Game;

public class SaveGame extends GameCommand{
    @Override
    public void execute(Game game) {
        game.saveGame();
    }
}
