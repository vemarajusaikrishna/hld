package atm.states;

import atm.ATM;

public class Authentication extends State {
    public Authentication(ATM atm) {
        super(atm);
    }

    @Override
    public void insertCard() {
        atm.getDisplay().writeToDisplay("Card already inserted.");
    }

    @Override
    public void readAndValidateCard() {
        atm.getDisplay().writeToDisplay("Card already read and validated successfully.");
    }

    @Override
    public void readAndValidatePin() {
         String pin =  atm.getKeypad().getInput();
         atm.validatePin(pin);
    }

    @Override
    public void ejectCard() {
        atm.getDisplay().writeToDisplay("Operation does not support.");
    }

    @Override
    public void displayError() {
        System.out.println("Operation does not support.");
    }

}
