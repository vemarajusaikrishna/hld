package atm;

import java.util.Map;

public class CashDispenser {

    private CashStorageBox cashStorageBox;

    public CashDispenser(CashStorageBox cashStorageBox) {
        this.cashStorageBox = cashStorageBox;
    }

    public void dispenseCash(Map<Integer,Integer> denominationMap) {

        cashStorageBox.removeCash(denominationMap);
        System.out.println("Please collect the cash...");
    }
}
