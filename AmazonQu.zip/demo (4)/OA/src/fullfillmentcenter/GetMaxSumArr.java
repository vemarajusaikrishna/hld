package fullfillmentcenter;

import java.util.PriorityQueue;
import java.util.Queue;

public class GetMaxSumArr {
    public static int getSum(int[] arr) {
        Queue<Integer> minHeap = new PriorityQueue<>();
        Queue<Integer> maxHeap = new PriorityQueue<>((a,b) -> Integer.compare(b, a));
        int[] sumArr = new int[arr.length];
        int n = arr.length / 3;
        int sum = 0;
        int result = 0;

        for (int i=0;i<arr.length;i++) {
            minHeap.add(arr[i]);
            sum += arr[i];
            if (minHeap.size() > n)
                sum -= minHeap.poll();
            sumArr[i] = sum;
        }

        sum = 0;
        for (int i=arr.length-1;i>=0;i--) {
            maxHeap.add(arr[i]);
            sum += arr[i];
            if (maxHeap.size() > n)
                sum -= maxHeap.poll();
            if (i>= n && maxHeap.size() == n) {
                result = Math.max(result, sumArr[i-1] - sum);
            }
        }

        return result;
    }

    public static void main(String ... args){
        System.out.println(getSum(new int[]{1, 3, 4, 7, 5, 2}));
        System.out.println(getSum(new int[]{5, -2, 3, 1, 2, -1, 4, 7, 2}));
    }
}
