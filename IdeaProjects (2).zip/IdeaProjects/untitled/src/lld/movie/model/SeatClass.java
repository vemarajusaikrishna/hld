package lld.movie.model;

public class SeatClass {
}
