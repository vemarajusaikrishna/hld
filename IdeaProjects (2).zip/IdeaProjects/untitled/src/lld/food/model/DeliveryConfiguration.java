package lld.food.model;

public class DeliveryConfiguration {

    private float etaWeight;
    private float successAndRatingWeight;
    private float workLoadWeight;



}
