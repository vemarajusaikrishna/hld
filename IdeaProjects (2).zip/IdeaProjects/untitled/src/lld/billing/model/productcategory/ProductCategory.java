package lld.billing.model.productcategory;

public abstract class ProductCategory {
    private double discount;

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
