package lld;

public class Food {


}
