//package atm.states;
//
//import atm.ATM;
//
//public class TransactionSelection extends State {
//    public TransactionSelection(ATM atm) {
//        super(atm);
//    }
//
//    @Override
//    public void insertCard() {
//        atm.getDisplay().writeToDisplay(("Card already inserted in slot.");
//    }
//
//    @Override
//    public void readAndValidateCard() {
//        atm.getDisplay().writeToDisplay("Card validation already completed successfully.");
//    }
//
//    @Override
//    public void readAndValidatePin() {
//        atm.getDisplay().writeToDisplay("Pin validation already completed successfully.");
//    }
//
//    public void selectTransaction()
//
//    @Override
//    public void ejectCard() {
//        atm.getDisplay().writeToDisplay("operation not supported");
//    }
//
//    @Override
//    public void displayError() {
//        atm.getDisplay().writeToDisplay("operation not supported.");
//    }
//}
