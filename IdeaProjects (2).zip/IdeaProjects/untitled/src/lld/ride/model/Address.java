package lld.ride.model;

public class Address {

    private String dNo;
    private String street;
    private String city;
    private String state;
    private String country;
}
