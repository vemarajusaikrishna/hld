package parkingLot.model;

public class Ticket {
}
