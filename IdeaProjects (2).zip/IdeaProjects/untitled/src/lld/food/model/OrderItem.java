package lld.food.model;

public class OrderItem {

    private String itemId;
    private String itemName;
    private int quantity;
    private float price;
}
