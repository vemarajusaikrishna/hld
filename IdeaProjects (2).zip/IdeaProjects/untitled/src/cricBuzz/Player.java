package cricBuzz;

import cricBuzz.enums.PlayerType;
import cricBuzz.score.card.BattingScoreCard;
import cricBuzz.score.card.BowlingScoreCard;

public class Player {

    private Person person;
    private PlayerType playerType;
    private BattingScoreCard battingScoreCard;
    private BowlingScoreCard bowlingScoreCard;
}
