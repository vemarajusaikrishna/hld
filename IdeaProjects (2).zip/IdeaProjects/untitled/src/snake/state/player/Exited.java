package snake.state.player;

import snake.Player;

public class Exited extends PlayerState {
    @Override
    public void rollDice(Player player) {
     System.out.println("Cannot roll dice.");
    }

    @Override
    public void move(Player player, int spaces) {
        System.out.println("Cannot move.");
    }

    @Override
    public void pause(Player player) {
        System.out.println("Cannot pause.");
    }

    @Override
    public void resume(Player player) {
        System.out.println("Cannot resume.");
    }

    @Override
    public void exitGame(Player player) {
        System.out.println("already exited from game");
    }
}
