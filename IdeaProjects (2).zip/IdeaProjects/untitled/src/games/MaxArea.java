package games;

import java.util.*;

public class MaxArea {
    public static final int MOD = 1_000_000_007;

    public static long getMaxTotalArea(int[] sticks) {
        Map<Integer,Integer> stickFrequency = new HashMap<>();

        for(int stick : sticks)
        {

            stickFrequency.put(-stick,stickFrequency.getOrDefault(-stick,0)+1);
        }


        PriorityQueue<int[]> heap = new PriorityQueue<>((a,b)->a[0]-b[0]);

        stickFrequency.forEach((key,value) -> heap.add(new int[]{key,value})) ;


        long area = 0;
        int pair1 = 0;
        int pair2 = 0;

        while(!heap.isEmpty())
        {

            int[] current = heap.poll();
            int repeat = current[1];

            if(repeat > 1)
            {

                repeat -= 2;
                pair2 -= current[0];
            }

            if(repeat ==1)
            {
                if(!heap.isEmpty() && current[0]+1 == heap.peek()[0])
                {
                    int[] next = heap.poll();
                    heap.add(new int[]{next[0],next[1]+1});
                }
            }
            else if(repeat > 1)
            {
                heap.offer(current);
            }


            if(pair1 != 0 && pair2 != 0)
            {
                area += (long)(pair1*pair2);
                area %= MOD;
                pair1 =0;
                pair2 =0;

            }
            else if(pair2 != 0)
            {
                pair1 = pair2;
                pair2 =0;
            }
        }

        return area%MOD;
    }

    public static void main(String[] args) {
        int[] arr1 = {2, 3, 3, 4, 6, 8, 8, 6,8};
        System.out.println(getMaxTotalArea(arr1));

        int[] arr2 = {3, 4, 5, 5, 6};
        System.out.println(getMaxTotalArea(arr2));

        int[] arr3 = {2, 6, 6, 2, 3, 5};
        System.out.println(getMaxTotalArea(arr3));
    }
}

