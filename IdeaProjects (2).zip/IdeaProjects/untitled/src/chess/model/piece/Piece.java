package chess.model.piece;

import chess.Board;
import chess.Cell;
import chess.model.enums.PieceColour;

import java.util.List;

public abstract class Piece {

    protected PieceColour pieceColour;

    public Piece(PieceColour pieceColour) {
        this.pieceColour = pieceColour;
    }

    protected boolean isKilled;
    protected int moves =0;

    public PieceColour getPieceColour() {
        return pieceColour;
    }

    public void setPieceColour(PieceColour pieceColour) {
        this.pieceColour = pieceColour;
    }

    public boolean isKilled() {
        return isKilled;
    }

    public void setKilled(boolean killed) {
        isKilled = killed;
    }

    public int getMoves() {
        return moves;
    }

    public void setMoves(int moves) {
        this.moves = moves;
    }

    //move validation and can define own movement logic for each piece
    public abstract boolean  canMove(Cell target, Board board);
    public abstract List<int[]> getLegalMoves(Cell target , Board board);

}
