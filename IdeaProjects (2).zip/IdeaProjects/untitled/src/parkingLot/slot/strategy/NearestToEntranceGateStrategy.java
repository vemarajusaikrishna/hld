package parkingLot.slot.strategy;

import parkingLot.model.ParkingSlot;

public class NearestToEntranceGateStrategy implements ParkingStrategy{
    @Override
    public ParkingSlot getParkingSpot() {
        return null;
    }
}
