package lld.movie.state;

public class Completed {

    //collects feeback review on movie ,theater
}
