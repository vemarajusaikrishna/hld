package snake.momento;

import java.util.List;
import java.util.Map;

public class GameStateMomento {

    private Map<Integer,Integer> playersPosition ;
    private int currentTurnIndex;
    private List<int[]> snakesPositions;
    private List<int[]> laddersdPositions;

    public Map<Integer, Integer> getPlayersPosition() {
        return playersPosition;
    }

    public void setPlayersPosition(Map<Integer, Integer> playersPosition) {
        this.playersPosition = playersPosition;
    }

    public int getCurrentTurnIndex() {
        return currentTurnIndex;
    }

    public void setCurrentTurnIndex(int currentTurnIndex) {
        this.currentTurnIndex = currentTurnIndex;
    }

    public List<int[]> getSnakesPositions() {
        return snakesPositions;
    }

    public void setSnakesPositions(List<int[]> snakesPositions) {
        this.snakesPositions = snakesPositions;
    }

    public List<int[]> getLaddersdPositions() {
        return laddersdPositions;
    }

    public void setLaddersdPositions(List<int[]> laddersdPositions) {
        this.laddersdPositions = laddersdPositions;
    }
}
