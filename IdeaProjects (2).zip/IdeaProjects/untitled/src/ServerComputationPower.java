import java.util.ArrayList;
import java.util.List;

public class ServerComputationPower {


    public static int makepowernondecreasing(int[] arr) {
        int n = arr.length;
        List<Integer> increments = new ArrayList<>();

        int sum = 0;
        for (int i = 0; i < arr.length - 1; i++) {
            int a = arr[i];
            int b = arr[i + 1];
            if (a > b) {
                sum += a - b;
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        int[] powers = {3, 4, 1, 6, 2};
        int result = makepowernondecreasing(powers);
        System.out.println("Sum of increments needed to make powers list non-decreasing: " + result);
    }
}

