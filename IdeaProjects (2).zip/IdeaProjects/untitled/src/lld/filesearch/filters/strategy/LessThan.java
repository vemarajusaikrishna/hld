package lld.filesearch.filters.strategy;

public class LessThan implements ComparisonStrategy {
    @Override
    public boolean compare(long given, long actual) {
        return given < actual;
    }
}
