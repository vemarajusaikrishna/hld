package lld.ride.servicee.states;

import lld.ride.model.Location;

public class WaitingForPickUp extends RideState{
    @Override
    public void searchDriver(Location source, Location dropOff) {

    }

    @Override
    public void generateTrackingDetails() {

    }

    @Override
    public void cancel() {

    }


}
