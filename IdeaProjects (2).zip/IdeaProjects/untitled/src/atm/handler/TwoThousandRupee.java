package atm.handler;

public class TwoThousandRupee extends DenominationHandler{

}
