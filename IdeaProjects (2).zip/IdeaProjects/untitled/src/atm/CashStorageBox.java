package atm;

import atm.exception.InsuffientFundsException;

import java.util.HashMap;
import java.util.Map;

public class CashStorageBox {

    private Map<Integer,Integer> denominationMap = new HashMap<>();
    private int totalAmount;

    public void addCash(Map<Integer,Integer> denominations)
    {
        for(Map.Entry<Integer,Integer> entry : denominations.entrySet())
        {
            int  denomination = entry.getKey();
            int count = entry.getValue();
            denominationMap.put(denomination, denominationMap.getOrDefault(denomination,0)+count);
            totalAmount += (denomination*count);
        }

    }

    public void removeCash(Map<Integer,Integer> denominations)
    {
     for(Map.Entry<Integer,Integer> entry : denominations.entrySet())
     {
         int  d = entry.getKey();
         int count = entry.getValue();
         if(!isDenominationPresent(d)) {
             continue;
         }
         if(getDenominationCount(d) <= count || count == -1)
         {
             denominationMap.remove(d);
             totalAmount -= (d*getDenominationCount(d));
         }
         else {
             denominationMap.put(d, denominationMap.get(d) - count);
             totalAmount -= (d*count);
         }
     }
    }
    private int getDenominationCount(int denomination)
    {
        return denominationMap.getOrDefault(denomination,0);
    }

    private boolean isDenominationPresent(int denomination)
    {
        return denominationMap.containsKey(denomination);
    }

}
