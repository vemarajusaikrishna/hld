Relationship

A theater has many screens
A screen has many seats

Same movie played in multiple shows (morning , aftenoon , evening)
Same screen host multiple shows

Multiple bookings can happen on same show

Multiple seats can be selected in single booking
and multiple bookings can select same seat in different show
So booking to seat is many-many

------------------
Booking life cycle

Idle
    - user login to account
    - user searches for theaters
Seat Selection
    - now session time starts
    - user selects seat and system applies lock for temporarily
    - session expires,go to expired state
PaymentPending
    -user selects payment method and provide details for payment
    -If success,go to confirmed state
    -else,retry for 3 times.If still failed ,go to failed state
    -session espires at any point , go to expired state
Confirmed
    - mark seat as RESERVED
    - push notification for booking confirmation
    - if cacnel command is invoked by user, got refundInitializig state
expired
   - go back to idle state to start new session
PaymentRefunding
   - refund payment
   - if success,update payment status,create refund record.go to seatReleasing state
seatRealisingState
   - release seat
   - if success,go to cancelleed state
cancelled
   - change status to CANCELLED
   - update the cacnellation reason also
completed
   - get feedback and rating about movie and theater experience.


BookingService

PaymentService
        Use factory design , to hold multiple payment methods
NotificationService
        Use event bus to send to delivery channels
SeatManagementService
       lockSeat()
       reserveSeat()





