package lld.movie.chain;

public class EmailChannel extends DeliveryChannelHandler{
    public EmailChannel(DeliveryChannelHandler deliveryChannelHandler) {
        super(deliveryChannelHandler);
    }

    @Override
    public void sendNotification(String message,User user) {

    }
}
