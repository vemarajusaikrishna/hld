package snake.commands.player;

import snake.Game;
import snake.Player;

public class ResumeGameCommand extends GameCommand {
    @Override
    public void execute(Game game) {
       game.resume();
    }

}
