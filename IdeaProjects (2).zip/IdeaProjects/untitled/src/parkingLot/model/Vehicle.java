package parkingLot.model;

public class Vehicle {
}
