package games;

public class GetMinimumValue {
}
