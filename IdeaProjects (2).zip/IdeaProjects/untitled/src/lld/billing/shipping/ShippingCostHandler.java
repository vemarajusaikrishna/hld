package lld.billing.shipping;

import lld.billing.model.Purchase;

public abstract class ShippingCostHandler {

    protected ShippingCostHandler shippingCostHandler;

    public ShippingCostHandler getShippingHandler() {
        return shippingCostHandler;
    }

    public void setShippingHandler(ShippingCostHandler shippingCostHandler) {
        this.shippingCostHandler = shippingCostHandler;
    }

    public abstract double getShippingCost(Purchase purchase);

}
