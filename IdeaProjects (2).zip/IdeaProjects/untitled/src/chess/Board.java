package chess;

public class Board extends Observable{

    private Cell[][] cell;
    private char[] ranks = {'a','b','c','d','e','f','g','h'};
    private char[] files = {'1','2','3','4','5','6','7','8'};

    public Board(Cell[][] cell) {
        this.cell = new Cell[8][8];
        initBlack();
        initWhite();
        
    }
    public Cell[][] getCell() {
        return cell;
    }
    public void setCell(Cell[][] cell) {
        this.cell = cell;
    }


}
