package atm.handler;

public class HundredRupee extends DenominationHandler{

}
