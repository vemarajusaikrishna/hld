package snake.commands.game;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class GameCommandFactory {

    Map<Integer, PlayerCommand> commandFactory = new HashMap<>();

    public void registerCommand(int input,Class<? extends PlayerCommand> command ) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        commandFactory.put(input,command.getDeclaredConstructor().newInstance());
    }

    public PlayerCommand removeCommand(int input) {
       return  commandFactory.remove(input);
    }

    public PlayerCommand getCommand(int input) {
        return  commandFactory.getOrDefault(input,null);
    }



}
