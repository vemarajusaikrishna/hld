package lld.movie.state;

public class Confirmed {
    //update payment details
    //send notification to user about booking confirmation
    //view booking details
    //provide support for cancel
    //if user attends movie,change to completed state

}
