package AWS;

import java.util.ArrayList;
import java.util.List;

public class FrontEndBackend{
static int calc(List<Integer> front, List<Integer> back, int n) {
    int[] f = new int[n + 1];
    int[] b = new int[n + 1];
    for (int i = 0; i < front.size(); i++) {
        f[i + 1] = front.get(i);
    }
    for (int i = 0; i < back.size(); i++) {
        b[i + 1] = back.get(i);
    }
    return calc(f, b, n);
}

static int calc(int[] front, int[] back, int n) {
    if (front.length <= back.length) {
        for (int i = 0; i < front.length; i++) {
            if (front[i] > back[i]) {
                return i + 1;
            }
        }
        return -1;
    }
    int[] bigger = front;
    int[] smaller = back;
    front = back;
    back = bigger;
    int result = calc(front, smaller, n);
    if (result != -1) {
        return result;
    }
    return calc(back, smaller, n);
}


    public static void main(String[] args) {
        List<Integer> front = new ArrayList<>();
        List<Integer> back = new ArrayList<>();
        front.add(1);
        front.add(2);
        front.add(3);
        back.add(1);
        back.add(2);
        back.add(1);
        int answer = calc(front, back, 3);
        System.out.println(answer); // => 2
    }
}