package lld.ratelimiter.decorator;

import java.net.http.HttpRequest;

public class ConcreteAPI implements API{
    @Override
    public void processRequest(String userId, HttpRequest httpRequest) {
        System.out.println("Processing request....");

    }
}
