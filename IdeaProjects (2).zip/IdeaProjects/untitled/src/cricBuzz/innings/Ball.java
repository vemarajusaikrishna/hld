package cricBuzz.innings;

import cricBuzz.enums.BallType;
import cricBuzz.Player;
import cricBuzz.enums.RunType;

import java.util.List;
import java.util.Observer;

public class Ball {

    private int ballNumber;
    private Player playedBy;
    private Player bowledBy;
    private BallType ballType;
    private RunType runType;
    List<Observer> observers;

    public void throwBall()
    {

    }

    public void notifyObserver()
    {

    }
}
