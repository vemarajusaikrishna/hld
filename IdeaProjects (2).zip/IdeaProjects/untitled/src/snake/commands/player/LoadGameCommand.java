package snake.commands.player;

import snake.Game;

public class LoadGameCommand extends GameCommand{
    @Override
    public void execute(Game game) {
        game.restoreGame();
    }
}
