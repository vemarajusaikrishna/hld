package lld.movie.state;

public class Failed {
    //update the payment status as failed
    //redirect to selection state
}
