package chess;

public class BoardBuilder {

    buildCells();

    buildPiecesOnBoard()
}
