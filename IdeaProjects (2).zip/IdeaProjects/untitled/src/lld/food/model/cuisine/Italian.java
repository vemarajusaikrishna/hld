package lld.food.model.cuisine;

public class Italian extends Cuisine {

    public Italian(String name) {
       super(name);
    }
}
