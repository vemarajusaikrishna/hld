package lld.ride.servicee;

import lld.ride.model.Location;

public class DriverMatchingService {


    public boolean assignDriver(Location location){
          //get the gridIndex where rider is there
          //find the nearby grids and get drivers
          //grid based indexing
        return true;
    }

    private String getGridIndex(Location location){
        return "ss";
    }

}
