package lld.billing.cost;

import lld.billing.discounts.DiscountHandler;
import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public  class Discount extends TotalCostDecorator {

    private DiscountHandler  discountHandler;
    public Discount(TotalCost totalCost, DiscountHandler discountHandler) {
        super(totalCost);
        this.discountHandler = discountHandler;
    }

    @Override
    public double calculateCost( Customer customer, Purchase purchase) {
        double discountRate = discountHandler.handle(customer,purchase);
        return totalCost.calculateCost(customer,purchase)*((double)100-discountRate);
    }
}
