package snake.state.game;

import snake.Game;

public class ResetState implements GameState {
    @Override
    public void initialize(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void pause(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void resume(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void stop(Game game) {
        game.setGameState(new StopState());
        game.exit();
    }

    @Override
    public void reset(Game game) {
        System.out.println("game is resetting it.Please wait.");
        //write logic to reset game.
        game.setGameState(new ActiveState());
        game.start();
    }

    @Override
    public void start(Game game) {
        System.out.println("Unsupported operation.");
    }
}
