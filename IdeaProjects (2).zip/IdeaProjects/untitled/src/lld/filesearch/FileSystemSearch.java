package lld.filesearch;

import lld.filesearch.composite.Component;
import lld.filesearch.composite.Folder;
import lld.filesearch.composite.File;
import lld.filesearch.filters.*;
import lld.filesearch.filters.strategy.Equals;
import lld.filesearch.filters.strategy.GreaterThan;
import lld.filesearch.filters.strategy.LessThan;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class FileSystemSearch {

    public static void main(String ... args){

        Folder root = new Folder("root");
        Folder folder1 = new Folder("folder1");
        Folder folder2 = new Folder("folder2");
        Folder folder3 = new Folder("folder3");

        File file1 = new File("file1","txt",10);
        File file2 = new File("file2","doc",10);
        File file3 = new File("file3","ppt",100);
        File file4 = new File("file4","xlx",100);
        File file5 = new File("file5","html",106);
        File file6 = new File("file6","java",16);

        root.addChildren(file1);
        root.addChildren(folder1);

        folder1.addChildren(file2);
        folder1.addChildren(file6);
        folder1.addChildren(folder2);

        folder3.addChildren(file3);
        folder3.addChildren(file4);
        folder3.addChildren(file5);

        //build query
        Specification<Component> nameMatch =  new NameFilter("report");
        Specification<Component> sizeMatchWithLessThan =  new SizeFilter(100,new LessThan());
        Specification<Component> sizeMatchWithGreaterThan =  new SizeFilter(100,new GreaterThan());
        Specification<Component> sizeMatchWithEquals =  new SizeFilter(100,new Equals());
        Specification<Component> extensionMatch = new ExtensionFilter("txt");


        Specification<Component> complexQuery = preparequery(nameMatch, sizeMatchWithLessThan, sizeMatchWithEquals, extensionMatch, sizeMatchWithGreaterThan);
        List<Component> result = executeQuery(complexQuery,root);

    }

    private static List<Component> executeQuery(Specification<Component> complexQuery, Component root) {
        List<Component> result =  new ArrayList<>();
        Queue<Component> queue = new LinkedList();
        if(root.getChildren().isEmpty())
            return result;
        queue.add(root);
        //perform BFS traversal on tree
        while(!queue.isEmpty()){
            Component component = queue.poll();
            for(Component file : component.getChildren()) {
                if(file.getChildren() == null){
                    //if it is file,then apply query on that
                    if(complexQuery.isSatisfiedBy(file)){
                        result.add(file);
                    }
                }
                else {
                    //add only directories
                    queue.add(component);
                }
            }
        }
        return result;

    }

    private static Specification<Component> preparequery(Specification<Component> nameMatch, Specification<Component> sizeMatchWithLessThan, Specification<Component> sizeMatchWithEquals, Specification<Component> extensionMatch, Specification<Component> sizeMatchWithGreaterThan) {
        Specification<Component> complexQuery  =
                (nameMatch.and(sizeMatchWithLessThan.or(sizeMatchWithEquals)))
                 .or(extensionMatch.and(sizeMatchWithGreaterThan.or(sizeMatchWithEquals)))
                        .or(sizeMatchWithEquals);
        return complexQuery;
    }
}
