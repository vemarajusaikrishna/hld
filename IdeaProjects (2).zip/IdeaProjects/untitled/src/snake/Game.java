package snake;

import chess.Board;
import snake.commands.game.PlayerCommand;
import snake.commands.player.GameCommand;
import snake.commands.player.GameCommandFactory;
import snake.momento.GameStateHistory;
import snake.momento.GameStateMomento;
import snake.state.game.ActiveState;
import snake.state.game.GameState;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Game {

    private List<Player> allPlayers;
    private GameCommandFactory gameCommandFactory;
    private snake.commands.game.GameCommandFactory gameCommandFactory;
    private GameState gameState;
    private GameStateHistory gameStateHistory;
    private Board1 board;
    private boolean isFinished;

    ;
    public Game(int snakes , int ladders, int finalPosition,int players) {
        this.allPlayers = new ArrayList<>(players);
        this.gameCommandFactory = new GameCommandFactory();
        this.gameState = new ActiveState();
        this.gameStateHistory = new GameStateHistory();
        this.board = new Board1(finalPosition);
    }

    public boolean start()
    {
       gameState.initialize(this);
    }
    public boolean pause()
    {
       gameState.pause(this);
    }
    public boolean resume()
    {
        gameState.resume(this);
    }
    public boolean exit()
    {
       gameState.stop(this);
    }
    public boolean reset()
    {
        gameState.reset(this);
    }

    public GameState getGameState() {
        return gameState;
    }

    public void setGameState(GameState gameState) {
        this.gameState = gameState;
    }

    public void saveGame(){
        GameStateMomento gameStateMomento = new GameStateMomento();
        gameStateHistory.saveGame(gameStateMomento);
    }

    public void restoreGame() {
       GameStateMomento gameStateMomento = gameStateHistory.restoreGame();
       //start reconstrcuting all
    }

    public void executeCommand(int input, int playerId) {
        //retreive the command from the factory.
     PlayerCommand gameCommand = playerCommandFactory.getCommand(input);
     if(gameCommand == null)
         throw new RuntimeException("No command found");
     Player player = allPlayers.get(playerId);
     gameCommand.execute(player);
    }
    public void executeCommand(int input) {
        //retreive the command from the factory.
        GameCommand gameCommand = gameCommandFactory.getCommand(input);
        if(gameCommand == null)
            throw new RuntimeException("No command found");
        gameCommand.execute(this);
    }
    private void initializeLadders(int ladders) {

        for(int i =1 ; i <= ladders ;i++)
        {
            while(true)
            {
                int head = ThreadLocalRandom.current().nextInt(0, board.getFinalPosition()-1);
                int tail = ThreadLocalRandom.current().nextInt(0, board.getFinalPosition()-1);

                if(head > tail)
                {
                    board.addLadder(tail,head);
                }

            }
        }
    }
    private void initializeSnakes(int snakes) {

        for(int i =1 ; i <= snakes ;i++)
        {
            while(true)
            {
                int head = ThreadLocalRandom.current().nextInt(0, board.getFinalPosition()-2);
                int tail = ThreadLocalRandom.current().nextInt(0, board.getFinalPosition()-2);

                if(head > tail)
                {
                    board.addLadder(head,tail);
                }

            }
        }
    }
    private void initializePlayers(){

    }
    public void run()
    {
        while(!isFinished){
            for(Player player : allPlayers){
                if(player.hasWon())
                  isFinished=true;
                player.takeTurn();
            }
        }
        gameState.
    }
}
