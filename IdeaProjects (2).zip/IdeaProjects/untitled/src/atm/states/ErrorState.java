package atm.states;

import atm.ATM;

public class ErrorState extends State {
    public ErrorState(ATM atm) {
        super(atm);
    }

    @Override
    public void insertCard() {

    }

    @Override
    public void validatePin() {

    }
}
