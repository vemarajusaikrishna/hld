package AWS;

public class MaximizeNegativePnLMonths {

    public static int maximizeNegativePnLMonths(int[] PnL) {
        int sum=PnL[0];
        int count=0;
        int n = PnL.length;
        for (int i = 0; i < n / 2; i++) {
            int temp = PnL[i];
            PnL[i] = PnL[n - i - 1];
            PnL[n - i - 1] = temp;
        }
        for (int i=1;i<PnL.length;i++)
        {
            if(sum-PnL[i] > 0)
            {
                sum=sum-PnL[i];
                count++;
            }
            else
            {
                sum=sum+PnL[i];
            }
        }
        System.out.println(count);
        return count;
    }

    public static void main(String[] args)
    {
        maximizeNegativePnLMonths(new int[]{5, 3, 1, 2});
        maximizeNegativePnLMonths(new int[]{5, 2, 3, 5, 2, 3});
        maximizeNegativePnLMonths(new int[]{1, 1, 1, 1, 1});

    }
}
