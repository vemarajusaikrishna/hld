package lld.food.model;

import parkingLot.model.Vehicle;

public class DeliveryPartner {

    private String id;
    private  PersonalInformation personalInformation;
    private  Map<String , DeliveryTask> activeDeliveryTask;
    private  Location location;
    private  int successRate;
    private  Review review;
    private Vehicle vehicle;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public PersonalInformation getPersonalInformation() {
        return personalInformation;
    }

    public void setPersonalInformation(PersonalInformation personalInformation) {
        this.personalInformation = personalInformation;
    }

    public Map<String, DeliveryTask> getActiveDeliveryTask() {
        return activeDeliveryTask;
    }

    public void setActiveDeliveryTask(Map<String, DeliveryTask> activeDeliveryTask) {
        this.activeDeliveryTask = activeDeliveryTask;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public int getSuccessRate() {
        return successRate;
    }

    public void setSuccessRate(int successRate) {
        this.successRate = successRate;
    }

    public Review getReview() {
        return review;
    }

    public void setReview(Review review) {
        this.review = review;
    }

    public Vehicle getVehicle() {
        return vehicle;
    }

    public void setVehicle(Vehicle vehicle) {
        this.vehicle = vehicle;
    }
}
