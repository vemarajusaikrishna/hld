package snake.state.player;

import snake.Player;

public class Win extends PlayerState{
    @Override
    public void rollDice(Player player) {
        System.out.println("game is already won.");
    }

    @Override
    public void move(Player player, int spaces) {
        System.out.println("game is already won.");
    }

    @Override
    public void pause(Player player) {
        System.out.println("game is already won.");
    }

    @Override
    public void resume(Player player) {
        System.out.println("game is already won.");
    }

    @Override
    public void exitGame(Player player) {
       player.setPlayerState(new Exited());
    }
}
