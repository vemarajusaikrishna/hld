package lld.food.model;

import java.util.List;

public class Review {

    private String reviewId;
    private float rating;
    private String comment;
    private List<String> tags;
}
