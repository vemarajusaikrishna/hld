package aws;

public class MaxStability {
}
