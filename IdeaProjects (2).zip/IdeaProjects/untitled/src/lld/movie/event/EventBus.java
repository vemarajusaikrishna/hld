package lld.movie.event;

public interface EventBus {

    void publish(Event event);
    void subscribe(String eventType,EventHandler handler);
}
