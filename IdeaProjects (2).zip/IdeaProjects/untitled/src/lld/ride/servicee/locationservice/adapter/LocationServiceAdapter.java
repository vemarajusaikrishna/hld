package lld.ride.servicee.locationservice.adapter;

import lld.ride.model.Address;
import lld.ride.model.Location;

import java.util.List;

public interface LocationServiceAdapter {

    public Location getCurrentLocation();
    public double calculateDistance(Location loc1, Location loc2);
    public double calculateEta(Location loc1,Location loc2);
    public Location geoCoding(Address address);
    public String reverseGeoCoding(Location location);
}
