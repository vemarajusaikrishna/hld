package lld.goodreads;

import lld.goodreads.model.Book;
import lld.goodreads.model.User;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class BookLookupStrategy {

    public  List<Book> getBooks(Map<String,Book> books,
                                Map<String, User> users,
                                String userId){

        return users.get(userId)
                .getBooks()
                .stream()
                .map(bookId->books.get(bookId))
                .collect(Collectors.toList());
    }

    public abstract List<Book> getTopUserBooksThatFriendsHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity);

    public abstract List<Book> getTopUserBooksThatNetworkHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity, int networkDepth);
}
