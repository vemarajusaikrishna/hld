package chess.model.enums;

public enum  GameStatus {

    WHITE_WIN,
    CHECK,


}
