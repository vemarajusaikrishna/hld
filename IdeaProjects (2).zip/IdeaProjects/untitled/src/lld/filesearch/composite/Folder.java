package lld.filesearch.composite;

import java.util.ArrayList;

public class Folder extends Component {

    public Folder(String name){
        super(name,"",0,new ArrayList<>());
    }

    public void addChildren(Component component){
        super.getChildren().add(component);
    }

}
