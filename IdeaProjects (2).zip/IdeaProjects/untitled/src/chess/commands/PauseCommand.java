package chess.commands;

import chess.Game;

public class PauseCommand implements Command{
    Game game;
    @Override
    public void execute() {

    }
}
