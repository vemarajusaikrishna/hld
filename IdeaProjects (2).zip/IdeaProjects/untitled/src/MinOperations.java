public class MinOperations {


    public static int findMinOpertions(int[] nums)
    {
        int diff = 0;
        int ret = 0;
        int length = nums.length ;


        for(int i = length -1; i >=0 ;i--)
        {

            ret += Math.abs(nums[i] + diff);

            diff += -(nums[i]+diff);
        }

        return ret;
    }


    public static void main(String[] args)
    {

        findMinOpertions(new int[]{3,2,0,0,-1});
    }
}
