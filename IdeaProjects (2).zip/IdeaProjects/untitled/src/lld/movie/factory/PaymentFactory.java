package lld.movie.factory;

import java.util.HashMap;
import java.util.Map;

public class PaymentFactory {

    private Map<String, PaymentMethod> paymentFactory = new HashMap();

    public void register(String paymentMethos,Class<? extends PaymentMethod> classname){

    }

    public void deRegister(String paymentMethod){

    }

    public PaymentMethod get(String paymentMethod){
        return null;
    }
}
