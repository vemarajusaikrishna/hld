package lld.billing.discounts;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public abstract class DiscountHandler {

    protected DiscountHandler discountHandler;

    public void setNextDiscountHandler(DiscountHandler discountHandler) {
        this.discountHandler = discountHandler;
    }

    public DiscountHandler getNextDiscountHandler() {
        return discountHandler;
    }

    public abstract double handle(Customer customer, Purchase purchase);
}
