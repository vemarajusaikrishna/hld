package lld.goodreads.model;

import java.util.*;

public class User {
    private String userId;
    private String username;
    private Set<String> friends;
    private Set<String> books;

    public User(){
        this.userId = UUID.randomUUID().toString();
        this.friends = new HashSet();
        this.books = new HashSet();

    }

    public Set<String> getFriends() {
        return friends;
    }

    public void setFriends(Set<String> friends) {
        this.friends = friends;
    }

    public Set<String> getBooks() {
        return books;
    }

    public void setBooks(Set<String> books) {
        this.books = books;
    }

    public String getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
