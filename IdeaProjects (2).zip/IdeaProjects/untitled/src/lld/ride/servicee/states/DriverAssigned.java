package lld.ride.servicee.states;

import lld.ride.model.Location;

public class DriverAssigned extends RideState{
    @Override
    public void searchDriver(Location source, Location dropOff) {

    }

    @Override
    public void genrateTrackingDetails() {

    }
}
