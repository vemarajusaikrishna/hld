package phoneInterview;

public class NthLevelConnections {
}
