package lld.food.state;

import lld.billing.model.Order;

public class Confirmed extends OrderState {
    public Confirmed(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        System.out.println("Accepted by restaurant already.");
        return true;
    }

    @Override
    public boolean assignDeliveryPartner() {
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        return false;
        //tracking id generated and restaurant assigned;
    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {

    }


    @Override
    public void getFeedbackAndRating() {

    }
}
