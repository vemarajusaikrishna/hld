package lld.goodreads;

import lld.goodreads.model.User;

import java.util.HashMap;
import java.util.Map;

public class UserService {

    private Map<String, User> allUsers;
    private  static UserService userService = null;

    public static UserService getInstance(){
      if(userService == null){
          userService = new UserService();
      }
      return userService;
    }

    private UserService(){
        this.allUsers = new HashMap<>();
    }

    public void createUser(String username){
        User user = new User();
        user.setUsername(username);
        this.allUsers.put(user.getUserId(),user);
    }

    public Map<String,User> getAllUsers(){
       return this.getAllUsers();
    }

    public void connectWithFriend(String userId ,String friendId){
        this.getAllUsers().get(userId).getFriends().add(friendId);
    }

    public void addBook(String userId,String bookId){
        this.getAllUsers().get(userId).getBooks().add(bookId);
    }

    public void removeUser(String userId){
        this.getAllUsers().remove(userId);
    }
}
