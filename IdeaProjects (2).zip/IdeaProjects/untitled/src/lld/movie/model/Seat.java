package lld.movie.model;

public class Seat {

    private int seatNumber;
    private String screenId;
    private int row;
    private SeatStatus status ;
    private SeatClass seatClass;
}
