package lld.billing.discounts;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class PaymentMethod extends DiscountHandler{


    public PaymentMethod( ) {
    }

    @Override
    public double handle(Customer customer, Purchase purchase) {
        double nextAppliedDiscount = this.getNextDiscountHandler() != null ? this.getNextDiscountHandler().handle(customer, purchase):0.0;
        double currentAppliedDiscount = purchase.getPaymentMethod().getDiscount();
        return Math.max(currentAppliedDiscount,nextAppliedDiscount);
    }
}
