package parkingLot;

import parkingLot.model.Ticket;
import parkingLot.slot.strategy.ParkingStrategy;

public class EntranceGate implements Runnable{
    int gateNo;
    public EntranceGate(int gateNO)
    {
        this.gateNo= gateNo;
    }
    @Override
    public void run() {
        generateTicket()
    }

    public Ticket generateTicket(ParkingStrategy, VehicleType)
    {
        

    }
}
