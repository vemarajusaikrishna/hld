package lld.billing.model.paymentmethods;

public class DebitCard extends PaymentMethod{
}
