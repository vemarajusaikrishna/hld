package aws;

import java.util.HashMap;
import java.util.Map;

public class BalancedSubSegments {

    public int getBalancedSegs(int[] caps) {
        Map<Integer, Integer> hm = new HashMap<>();
        int result = 0;

        for (int i=2;i<caps.length;i++) {
            if (caps[i] == caps[i-1] && caps[i] == caps[i-2])
                result++;
        }

        for (int i=0;i<caps.length;i++) {
            if (hm.containsKey(caps[i])) {
                int idx = hm.get(caps[i]);
                if (caps[i-1] - caps[idx] == caps[i])
                    result++;
            }
            hm.put(caps[i], i);
            if (i > 0)
                caps[i] += caps[i-1];
        }

        return result;
    }
}
