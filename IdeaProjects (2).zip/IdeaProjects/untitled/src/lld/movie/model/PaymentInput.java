package lld.movie.model;

public interface PaymentInput {
}
