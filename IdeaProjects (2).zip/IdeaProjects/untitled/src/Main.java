import java.util.PriorityQueue;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    static int[][] memo = null;
    private static final int M = (int) (1e9) + 7;
    public static void main(String[] args) {


       String s = "!!!!!!!" ;


        int x = 23;
        int y = 47;
         memo = new int[s.length()][s.length() + 1];
        for (int i = 0; i < s.length(); i++) {
            for (int j = 0; j <= s.length(); j++) {
                memo[i][j] = -1;
            }
        }
        System.out.println(calc(s.length() - 1, 0, s, x, y));*/
        }

    private static int calc(int i, int zeroCount, String s, int x, int y) {
        if(i < 0)
        {
            return 0;
        }

        if(memo[i][zeroCount] != -1)
        {
            return memo[i][zeroCount];
        }

        if(s.charAt(i) == '0')
        {
            int ans = (s.length() -(i+1)-zeroCount)*x-calc(i-1,zeroCount+1,s,x,y);
            memo[i][zeroCount] = ans % M;
            return memo[i][zeroCount];
        }
        else if(s.charAt(i) == '1')
        {    int ans = (zeroCount)*y-calc(i-1,zeroCount,s,x,y);
            memo[i][zeroCount] = ans % M;
            return memo[i][zeroCount];
        }
        else
        {
            int a = (s.length() -(i+1)-zeroCount)*x-calc(i-1,zeroCount+1,s,x,y);
            int b =  (zeroCount)*y-calc(i-1,zeroCount,s,x,y);
            int ans = Math.min(a,b) % M;
            memo[i][zeroCount] = ans ;
            return ans;
        }
    }
}


