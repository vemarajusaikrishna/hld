package lld.food.reposit.restaurant;

import lld.food.model.Location;
import lld.food.model.Restaurant;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class RestaurantRepository {

   private TreeMap<Double, TreeMap<Double,Integer>> geoIndex = new TreeMap();
   private Map<Integer, Restaurant> restaurantMap = new HashMap<>();


   public void remove(int restaurantId){
      Restaurant restaurant = restaurantMap.get(restaurantId);
      Location location = restaurant.getLocation();
      restaurantMap.remove(restaurantId);
      geoIndex.get(location.getLatitude()).remove(location.getLongitude());
   }

    public void add(Restaurant restaurant){
        //need to throw error RestaurantAlreadyExists.
        restaurantMap.put(restaurant.getId(),restaurant);
        Location location = restaurant.getLocation();
        geoIndex.putIfAbsent(location.getLatitude(),new TreeMap<>());
        geoIndex.get(location.getLatitude()).putIfAbsent(location.getLongitude(), restaurant.getId());
   }

   public List<Restaurant> getRestaurantByName(int radius, String name){
   return null;

   }

}
