package lld.billing.discounts;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public class OrderValue extends DiscountHandler {
    private int value ;
    private double discount;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    public double getDiscount() {
        return value;
    }

    public void setValue(double value) {
        this.discount = discount;
    }

    @Override
    public double handle(Customer customer, Purchase purchase) {
        double nextPrice = this.getNextDiscountHandler() != null ? this.getNextDiscountHandler().handle(customer, purchase):0.0;

        double nextAppliedDiscount = this.getNextDiscountHandler() != null ? this.getNextDiscountHandler().handle(customer, purchase):0.0;
        double currentAppliedDiscount = purchase.getOrderVale()>value?discount:0.0;
        return Math.max(currentAppliedDiscount,nextAppliedDiscount);
    }
}
