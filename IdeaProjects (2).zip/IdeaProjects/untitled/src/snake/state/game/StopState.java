package snake.state.game;

import snake.Game;

public class StopState implements GameState {
    @Override
    public void initialize(Game game) {
        System.out.println("Unsupported operation.");

    }

    @Override
    public void pause(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void resume(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void stop(Game game) {
        System.out.println("Resource deallocation is performing.....");
        //write deallocation logic
        System.out.println("Game stopped");
        //ask user if he wants to restart of exit game.
        game.setGameState(new InitializeState());
    }

    @Override
    public void reset(Game game) {
        System.out.println("Unsupported operation.");
    }

    @Override
    public void start(Game game) {
        System.out.println("Unsupported operation.");
    }
}
