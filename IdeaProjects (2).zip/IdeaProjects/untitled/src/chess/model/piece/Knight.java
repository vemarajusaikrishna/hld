package chess.model.piece;

public class Knight {
}
