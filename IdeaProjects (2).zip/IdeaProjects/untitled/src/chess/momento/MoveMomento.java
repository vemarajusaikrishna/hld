package chess.momento;

import chess.model.piece.Piece;

public class MoveMomento {

    private String fromPosition;
    private String toPosition;
    private Piece sourcePiece;

    public String getFromPosition() {
        return fromPosition;
    }

    public void setFromPosition(String fromPosition) {
        this.fromPosition = fromPosition;
    }

    public String getToPosition() {
        return toPosition;
    }

    public void setToPosition(String toPosition) {
        this.toPosition = toPosition;
    }

    public Piece getSourcePiece() {
        return sourcePiece;
    }

    public void setSourcePiece(Piece sourcePiece) {
        this.sourcePiece = sourcePiece;
    }

    public Piece getCapturedPiece() {
        return capturedPiece;
    }

    public void setCapturedPiece(Piece capturedPiece) {
        this.capturedPiece = capturedPiece;
    }

    private Piece capturedPiece;

    public MoveMomento(String fromPosition, String toPosition, Piece sourcePiece, Piece capturedPiece) {
        this.fromPosition = fromPosition;
        this.toPosition = toPosition;
        this.sourcePiece = sourcePiece;
        this.capturedPiece = capturedPiece;
    }
}
