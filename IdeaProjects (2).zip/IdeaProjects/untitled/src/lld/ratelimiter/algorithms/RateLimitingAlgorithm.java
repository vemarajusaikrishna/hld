package lld.ratelimiter.algorithms;

import lld.ratelimiter.observer.Observable;

public abstract class RateLimitingAlgorithm extends Observable {

    public abstract boolean handleRequest(String userId);
}
