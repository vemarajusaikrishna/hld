package lld.movie.model;

public class PaymentStatus {
}
