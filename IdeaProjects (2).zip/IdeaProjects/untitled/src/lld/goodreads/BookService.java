package lld.goodreads;
import lld.goodreads.model.Book;

import java.util.HashMap;
import java.util.Map;

public class BookService {

    private Map<String, Book> allBooks;
    private static BookService bookService;

    private BookService() {
        this.allBooks = new HashMap<>();
    }
    public static BookService getInstance(){
        if(bookService == null){
            bookService = new BookService();
        }
        return bookService;
    }

    public Map<String, Book> getAllBooks() {
        return allBooks;
    }


    public void createBook(String bookTitle){
        Book book = new Book();
        book.setBookTitle(bookTitle);
        this.allBooks.put(book.getBookTitle(),book);
    }
    public void removeBook(String bookId){
        if(allBooks.containsKey(bookId)){
            allBooks.remove(bookId);
        }
    }
}
