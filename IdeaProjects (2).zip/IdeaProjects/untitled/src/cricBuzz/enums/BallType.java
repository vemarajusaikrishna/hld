package cricBuzz.enums;

public enum BallType {

    NORMAL,
    WIDE,
    NO_BALL
}
