package chess.commands;

public class ResumeCommand implements Command{
    @Override
    public void execute() {

    }
}
