package lld.ride.servicee.states;

import lld.ride.model.Location;

public class Cancelled extends RideState{
    @Override
    public void searchDriver(Location source, Location dropOff) {

    }

    @Override
    public void genrateTrackingDetails() {

    }
}
