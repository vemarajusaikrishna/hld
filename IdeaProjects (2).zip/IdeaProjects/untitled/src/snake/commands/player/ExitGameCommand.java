package snake.commands.player;

import snake.Game;
import snake.Player;

public class ExitGameCommand extends GameCommand {
    @Override
    public void execute(Game game) {
      game.exit();
    }

}
