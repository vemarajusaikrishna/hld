//package filedownloader;
//
//import java.io.BufferedInputStream;
//import java.io.FileOutputStream;
//import java.io.IOException;
//import java.net.HttpURLConnection;
//import java.net.URL;
//import java.nio.file.Path;
//
//public class ChunkWiseFileDownload {
//
//
//      public static void fileDownload()
//      {
//            URL fileUrl = new URL(fileURL);
//            Path filePath =
//          HttpURLConnection  httpURLConnection=null;
//          int responseCode = 200;
//          try {
//              httpURLConnection = (HttpURLConnection) fileUrl.openConnection();
//              //check if connection is success
//             responseCode =  httpURLConnection.getResponseCode();
//          } catch (IOException e) {
//              throw new RuntimeException(e);
//          }
//
//          if(responseCode == 200)
//          {
//
//              //read fileName from content-disposition header
//            String disposition =   httpURLConnection.getHeaderField("Content-Disposition");
//            int index = disposition.indexOf("fileName=");
//              String filename= "";
//              if(index > 0)
//            {
//                filename = disposition.substring(index+10,disposition.length()-1);
//
//            }
//
//              try {
//                  BufferedInputStream in = new BufferedInputStream(httpURLConnection.getInputStream());
//                  FileOutputStream out = new FileOutputStream(savePath + filename);
//
//                  int chuckSize=10;
//                  byte[] buffer = new byte[chuckSize];
//                  int bytesread =0;
//
//                  while((bytesread=in.read(buffer) )!= -1)
//                  {
//                        out.write(buffer,0,bytesread);
//                  }
//              } catch (IOException e) {
//                  throw new RuntimeException(e);
//              }
//
//          }
//          else {
//
//              //no file to download
//          }
//      }
//}
