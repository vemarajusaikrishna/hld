//package kindle;
//
//import java.util.*;
//
//public class MovieTracker {
//
//    public String getFrequentlyViewdMovie(User user)
//    {
//        Map<String,Integer> movieFrequencyCount  = new HashMap<>();
//
//        Set<User> visited = new HashSet<>();
//
//        Queue<User> friendQueue = new LinkedList<>();
//        friendQueue.add(user);
//
//        visited.add(user);
//
//        while(!friendQueue.isEmpty())
//        {
//            //poll firend
//            User friend = friendQueue.poll();
//
//            visited.add(friend) ;
//
//            //iterate over all the movies
//            for(String movie : friend.getMoviewishList())
//            {
//                movieFrequencyCount.put(movie,movieFrequencyCount.getOrDefault(movie,0)+1);
//            }
//
//            //iterate over all the friend
//
//            for(User immediateFriend : friend.getFriends())
//            {
//                if(!visited.contains(immediateFriend))
//                {
//                    friendQueue.add(immediateFriend);
//                }
//            }
//
//
//
//        }
//
//
//
//    }
//}
