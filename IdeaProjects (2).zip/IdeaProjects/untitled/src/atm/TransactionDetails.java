package atm;

public class TransactionDetails {
}
