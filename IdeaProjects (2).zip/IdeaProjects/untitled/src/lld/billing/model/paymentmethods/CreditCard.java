package lld.billing.model.paymentmethods;

public class CreditCard extends PaymentMethod {

}
