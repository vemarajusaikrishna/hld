package snake.state.game;

import snake.Game;

public class PausedState implements GameState{
    @Override
    public void initialize(Game game) {

    }

    @Override
    public void pause(Game game) {
         if(game.getGameState() instanceof PausedState)
             System.out.println("Game already in paused state.");
         game.saveGame();
    }

    @Override
    public void resume(Game game) {
        System.out.println("Game is resuming......");
        game.restoreGame();
        game.setGameState(new ActiveState());
        game.start();
    }

    @Override
    public void stop(Game game) {
        System.out.println("Game is stopping......");
        game.setGameState(new StopState());
        game.exit();
    }

    @Override
    public void reset(Game game) {
        game.setGameState(new ResetState());
        game.reset();
    }

    @Override
    public void start(Game game) {

    }
}
