package lld.ride.servicee;

public class UserProfile {

    private UserFactory userFactory;

    public void createProfile(){

    }
    public void delete(String userId){

    }
    public void update(String userId,String emailId,String contactNumber){

    }
    public void getUser(String userId){

    }
}
