package cricBuzz.observer;

public class BattingScoreCardObserver implements ScoreCardUpdator {
}
