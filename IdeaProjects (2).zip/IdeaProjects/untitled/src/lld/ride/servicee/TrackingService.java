package lld.ride.servicee;

import lld.ride.model.Location;
import lld.ride.model.RideTracker;
import lld.ride.repository.TrackingRepository;
import lld.ride.servicee.locationservice.LocationService;

public class TrackingService {
    private LocationService locationService;
    private TrackingRepository trackingRepository;


    public TrackingService(LocationService locationService, TrackingRepository trackingRepository) {
        this.locationService = locationService;
        this.trackingRepository = trackingRepository;
    }

    public void generateTrackingDetails(Location driver, Location rider){

    }

    public void updateTrackingDetails(Location source, Location destination){
        //use location service to calculate the values
    }

    public RideTracker getTrackingDetails(String trackingId){
       return null;
    }

    public void removeTrackingDetails(String trackingId){

    }


}
