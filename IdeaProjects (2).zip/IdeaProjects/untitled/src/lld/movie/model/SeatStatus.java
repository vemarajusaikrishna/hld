package lld.movie.model;

public enum SeatStatus {

    RESERVED,
    AVAILABLE,
    HOLD;
}
