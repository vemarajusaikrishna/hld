package lld.food.state;

import lld.billing.model.Order;

public class OutForDelivery extends OrderState {
    public OutForDelivery(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        return false;
    }

    @Override
    public boolean assignDeliveryPartner() {
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        return false;
        //once driver picked up,
        // calculate eta and start the realtime tracking driver.

    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {

    }


    @Override
    public void getFeedbackAndRating() {

    }
}
