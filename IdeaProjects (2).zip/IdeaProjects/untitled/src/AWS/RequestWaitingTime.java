package AWS;

import java.util.HashMap;
import java.util.Map;

public class RequestWaitingTime {

    public static int[] findRequestsInQueue(int[] wait) {
        // O(N)
        int requests = wait.length; // # of pending requests
        Map<Integer, Integer> counts = new HashMap<>();
        for (int time : wait) {
            counts.merge(time, 1, Integer::sum);
        }

        int n = wait.length;
        int[] result = new int[n];
        int time = 0; // real / running time
        for (int waitingTime : wait) {
            if (waitingTime > time) {

                result[time++] = requests--;
                counts.merge(waitingTime, -1, Integer::sum);
                if (counts.get(waitingTime) == 0) {
                    counts.remove(waitingTime);
                }
            }
            int  noOfReqExpired = counts.getOrDefault(time, 0);
            if (noOfReqExpired > 0) {
                requests -= noOfReqExpired;
                counts.remove(time);
            }
        }

        return result;
    }

    public static void main(String[] args)
    {



       System.out.println( findRequestsInQueue(new int[] { 2, 2, 3, 1, 1, 4, 5, 3, 3, 10, 7}).toString());
    }


}
