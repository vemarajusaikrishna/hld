package snake.state.game;

import snake.Game;

public interface GameState {


    void initialize(Game game);

    void pause(Game game);

    void resume(Game game);

    void stop(Game game);

    void reset(Game game);

    void start(Game game);
}
