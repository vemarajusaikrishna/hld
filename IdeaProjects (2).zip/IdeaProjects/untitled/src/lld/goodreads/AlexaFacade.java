package lld.goodreads;

import lld.goodreads.model.Book;
import lld.goodreads.model.User;

import java.util.List;
import java.util.Map;

public class AlexaFacade {

    private UserService userService;
    private BookLookupStrategy bookLookupStrategy;
    private BookService bookService;

    public AlexaFacade(){
       initialize();
    }

    private void initialize(){
        this.userService = UserService.getInstance();
        this.bookService = BookService.getInstance();
        this.bookLookupStrategy = new BookLookUpStrategyImpl();
    }
    public void createUser(String username){
         userService.createUser(username);
    }
    public void addFriend(String userId1, String userId2){
        userService.connectWithFriend(userId1,userId2);
        userService.connectWithFriend(userId2,userId1);
    }
    public void addBookToUser(String userId, String bookId){
        userService.addBook(userId,bookId);
    }
    public  List<Book> getTopUserBooksThatFriendsHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity){
        return bookLookupStrategy.getTopUserBooksThatFriendsHasRead(
                bookService.getAllBooks(),
                userService.getAllUsers(),
                userId,
                10
        );
    }

    public  List<Book> getTopUserBooksThatNetworkHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity, int networkDepth){
       return bookLookupStrategy.getTopUserBooksThatNetworkHasRead(
                bookService.getAllBooks(),
                userService.getAllUsers(),
                userId,
                10,
               4
        );
    }
}
