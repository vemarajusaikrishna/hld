package lld.filesearch.filters;

import lld.filesearch.composite.Component;
import lld.filesearch.filters.strategy.ComparisonStrategy;

public class SizeFilter implements Specification<Component>{
    private long size ;
    private final ComparisonStrategy comparisonStrategy;


    public SizeFilter(long size, ComparisonStrategy comparisonStrategy) {
        this.size = size;
        this.comparisonStrategy = comparisonStrategy;
    }

    @Override
    public boolean isSatisfiedBy(Component item) {
        return comparisonStrategy.compare(size,item.getSize());
    }
}
