package snake.commands.player;

import snake.Game;
import snake.Player;

public abstract class GameCommand {

    public abstract void execute(Game game);
}
