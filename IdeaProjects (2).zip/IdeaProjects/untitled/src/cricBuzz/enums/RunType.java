package cricBuzz.enums;

public enum RunType {

    SINGLE,
    TWO,
    FOUR,
    SIX,
    WIDE_RUN;
}
