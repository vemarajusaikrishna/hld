package com.oauth.auth.demo.auth;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.server.authorization.OAuth2Authorization;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configuration.OAuth2AuthorizationServerConfiguration;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configurers.OAuth2AuthorizationServerConfigurer;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
@Configuration
public class SecurityConfig {

    @Bean
    @Order(Ordered.HIGHEST_PRECEDENCE)
    public SecurityFilterChain webFilterSecurityChain(HttpSecurity httpSecurity,) throws Exception {
        OAuth2AuthorizationServerConfigurer authorizationServerConfigurer = OAuth2AuthorizationServerConfigurer.authorizationServer();

        httpSecurity
                .securityMatcher(authorizationServerConfigurer.getEndpointsMatcher())
                .with(authorizationServerConfigurer, (authorizationServer) ->
                        authorizationServer
                                .clientAuthentication(clientAuthentication ->
                                        clientAuthentication
                                                        .authenticationConverter(authenticationConverter)
                                                        .authenticationConverters(authenticationConvertersConsumer)
                                                        .authenticationProvider(authenticationProvider)
                                                        .authenticationProviders(authenticationProvidersConsumer)
                                                        .authenticationSuccessHandler(authenticationSuccessHandler)
                                                        .errorResponseHandler(errorResponseHandler)
                                        )
                                .oidc(Customizer.withDefaults())	// Initialize `OidcConfigurer`
                );
        return httpSecurity.build();
    }
}
