package lld.ratelimiter.observer;


public class MetricsCollectionService implements Observer  {
    @Override
    public void update(String userId, String endpoint) {
        System.out.println("Metrics captured successfully");
    }
}
