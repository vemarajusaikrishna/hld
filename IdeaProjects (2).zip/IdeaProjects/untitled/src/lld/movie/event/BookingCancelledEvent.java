package lld.movie.event;

public class BookingCancelledEvent implements Event{
    @Override
    public String eventType() {
        return "";
    }

    @Override
    public String payload() {
        return "";
    }
}
