package cricBuzz.score.card;

public class BattingScoreCard {

    private int runs;
    private int fours;
    private int six;
    private int strikeRte;
    private int ballsPlayed;

}
