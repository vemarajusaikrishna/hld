package lld.food.reposit.deliveryPartner;

import lld.food.model.DeliveryTracker;
import lld.food.model.Location;

import java.util.HashMap;
import java.util.Map;

public class DeliveryTrackerRepository {

private Map<String, DeliveryTracker> deliveryTrackerMap = new HashMap<>();

public void addTracker(DeliveryTracker deliveryTracker){
     deliveryTrackerMap.putIfAbsent(deliveryTracker.getOrderId(),deliveryTracker);
}

public DeliveryTracker getTracker(String orderId){
  return  deliveryTrackerMap.get(orderId);
}

public void updateTracker(String orderId, Location location){
    DeliveryTracker tracker = deliveryTrackerMap.get(orderId);
    if(tracker != null){
        tracker.updateLocation(location);
    }
}
public void completeTracker(String orderId){
    DeliveryTracker tracker = deliveryTrackerMap.get(orderId);
    if(tracker != null){
        tracker.setCompleted(true);
    }
}
}
