package parkingLot;

import parkingLot.floor.ParkingFloorManager;

import java.util.HashMap;
import java.util.Map;

public class ParkingLotManager {

    private Map<Integer, ParkingFloorManager> floors = new HashMap<>();

    public boolean register(int floorId)
    {
        floors.put(floorId,new ParkingFloorManager());
        return true;
    }

    public boolean deRegister(int floorId)
    {
        floors.remove(floorId);
        return true;
    }
    public ParkingFloorManager getFloor(int floorId) {
        if(floors.containsKey(floorId))
            return floors.get(floorId);
        return null;
    }

}
