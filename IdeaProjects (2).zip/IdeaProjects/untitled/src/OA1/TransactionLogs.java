package OA1;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class TransactionLogs {


    public static void processLogs(String[] transactions, int threshold)
    {

        Map<String,Integer> map = new TreeMap<>();

        for(String transaction : transactions)
        {

            String[] transactionArray = transaction.split(" ");
            String sender = transactionArray[0];
            String receiver = transactionArray[1];

            if(!sender.equals(receiver))
            {
                map.put(receiver,map.getOrDefault(receiver,0)+1);
            }

                map.put(sender,map.getOrDefault(sender,0)+1);
        }
        List<String> ans = new ArrayList<>();
        map.forEach((key,value)-> {

            if(value >= threshold)
            {
                ans.add(key);
            }
        });

        System.out.println(ans);
    }

    public static void main(String... args)
    {
         processLogs(new String[]{"9 7 50", "22 7 20", "33 7 50", "22 7 30"},3);
    }
}
