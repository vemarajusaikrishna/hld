package com.oauth.auth.demo.auth;

import org.springframework.context.annotation.Import;
import org.springframework.security.oauth2.server.authorization.config.annotation.web.configuration.OAuth2AuthorizationServerConfiguration;
import org.springframework.security.oauth2.server.authorization.settings.AbstractSettings;

import java.util.Map;
import org.springframework.security.oauth2.server.authorization.settings.AuthorizationServerSettings;

@Import(OAuth2AuthorizationServerConfiguration.class)
public class AuthorizationServerSettingsConfig {

    public AuthorizationServerSettings.Builder builder() {
        return AuthorizationServerSettings
                .builder()
                .authorizationEndpoint("/oauth2/authorize")
                .deviceAuthorizationEndpoint("/oauth2/device_authorization")
                .deviceVerificationEndpoint("/oauth2/device_verification")
                .tokenEndpoint("/oauth2/token")
                .tokenIntrospectionEndpoint("/oauth2/introspect")
                .tokenRevocationEndpoint("/oauth2/revoke")
                .jwkSetEndpoint("/oauth2/jwks")
                .oidcLogoutEndpoint("/connect/logout")
                .oidcUserInfoEndpoint("/userinfo")
                .oidcClientRegistrationEndpoint("/connect/register");
    }
}
