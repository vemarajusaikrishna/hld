package parkingLot.slot;

import parkingLot.model.ParkingSlot;
import parkingLot.slot.strategy.ParkingStrategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class ParkingSlotManager {

    protected Map<Integer,ParkingSlot> availableSpots = new HashMap<>();
    protected Map<Integer,ParkingSlot> occupied = new HashMap<>();

    public ParkingSlotManager(Map<Integer, ParkingSlot> availableSpots, Map<Integer, ParkingSlot> occupied, ParkingStrategy parkingStrategy) {
        this.availableSpots = availableSpots;
        this.occupied = occupied;
    }

    public boolean registerParkingSlot(ParkingSlot parkingSlot) {
        availableSpots.put(parkingSlot.getSlotId(),parkingSlot);
        return true;
    }
    public boolean deRegisterParkingSlot(int slotId) {
        availableSpots.remove(slotId);
        return true;
    }

    public ParkingSlot getParkingSlot(ParkingStrategy parkingStrategy){
        return parkingStrategy.getParkingSpot();
    }

}
