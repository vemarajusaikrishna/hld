package snake.state.player;

import snake.Player;

public class Idle extends PlayerState {
    @Override
    public void rollDice(Player player) {
        System.out.println("Waiting for the turn .");
        player.setPlayerState(new RollingDice());
    }

    @Override
    public void move(Player player, int spaces) {
        System.out.println("Cannot move,must roll the dice first");
    }

    @Override
    public void pause(Player player) {
       player.setPlayerState(new PauseState());
    }

    @Override
    public void resume(Player player) {
        System.out.println("Game is already active");
    }

    @Override
    public void exitGame(Player player) {
        player.setPlayerState(new Exited());
        player.exit();
    }
}
