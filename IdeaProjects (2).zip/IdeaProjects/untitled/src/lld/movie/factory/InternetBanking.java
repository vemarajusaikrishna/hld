package lld.movie.factory;

import lld.movie.model.PaymentInput;

public class InternetBanking implements PaymentMethod{


    @Override
    public boolean proceedPayment(PaymentInput input) {
        return false;
    }

    @Override
    public boolean refund(String transactionId) {
        return false;
    }
}
