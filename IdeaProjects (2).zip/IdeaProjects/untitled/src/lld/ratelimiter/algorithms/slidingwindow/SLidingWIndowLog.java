package lld.ratelimiter.algorithms.slidingwindow;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class SLidingWIndowLog {

    private Map<String, Queue<Long>> clientRequestsMap;
    private int maxRequestAllowed;
    private long windowSize;

    private boolean isValid(String clientId){

     //check the cleint id is new or not
        clientRequestsMap.putIfAbsent(clientId,new LinkedList<>());
        //remove any requests older than windowSize
        long current = System.currentTimeMillis();
        Queue<Long> clientQueue = clientRequestsMap.get(clientId);
        while(!clientQueue.isEmpty() && current - clientQueue.peek() > windowSize ){
            clientQueue.poll();
        }

        //now check the size of queue;
        if(clientQueue.size() < maxRequestAllowed){
            clientQueue.add(current);
            return true;
        }
        return false;

    }
}
