package lld.billing.discounts;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

import java.util.HashMap;
import java.util.Map;

public class CouponCode extends DiscountHandler {
    private Map<String,Integer> couponCodes;

    public CouponCode() {
        this.couponCodes = new HashMap<>();
    }

    public void addCouponCode(String couponCode, int dicountPercentage){
        couponCodes.put(couponCode, dicountPercentage);
    }

    public void removeCouponCOde(String couponCode){
        couponCodes.remove(couponCode);
    }
    @Override
    public double handle(Customer customer, Purchase purchase) {
        double nextAppliedDiscount = this.getNextDiscountHandler() != null ? this.getNextDiscountHandler().handle(customer, purchase):0.0;
        double currentAppliedDiscount = couponCodes.getOrDefault(purchase.getCupon(),0);
        return Math.max(currentAppliedDiscount,nextAppliedDiscount);

    }
}
