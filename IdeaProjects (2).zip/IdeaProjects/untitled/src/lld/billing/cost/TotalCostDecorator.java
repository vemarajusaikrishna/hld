package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public abstract class TotalCostDecorator implements TotalCost{

    protected TotalCost totalCost;

    public TotalCostDecorator(TotalCost totalCost) {
        this.totalCost = totalCost;
    }

}
