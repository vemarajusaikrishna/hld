package lld.ride.servicee.locationservice.adapter;

import lld.ride.model.Address;
import lld.ride.model.Location;
import lld.ride.servicee.locationservice.MapBoxLocationService;

import java.util.List;

public class MapBoxAdapter implements LocationServiceAdapter {

    private MapBoxLocationService mapBoxLocationService;

    public MapBoxAdapter(MapBoxLocationService mapBoxLocationService) {
        this.mapBoxLocationService = mapBoxLocationService;
    }

    @Override
    public Location getCurrentLocation() {
        return null;
    }

    @Override
    public double calculateDistance(Location loc1, Location loc2) {
        return 0;
    }

    @Override
    public double calculateEta(Location loc1, Location loc2) {
        return 0;
    }


    @Override
    public Location geoCoding(Address address) {
        return null;
    }

    @Override
    public String reverseGeoCoding(Location location) {
        return "";
    }
}
