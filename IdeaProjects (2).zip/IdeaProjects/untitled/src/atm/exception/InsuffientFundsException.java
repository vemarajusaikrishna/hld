package atm.exception;

public class InsuffientFundsException extends Exception {
}
