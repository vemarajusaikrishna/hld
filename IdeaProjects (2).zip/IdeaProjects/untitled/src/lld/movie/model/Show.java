package lld.movie.model;

import java.time.LocalTime;

public class Show {

    private String showId;
    private String screenId;
    private String movieId;
    private LocalTime showTime;
}
