package atm.states;

import atm.*;

import javax.swing.table.AbstractTableModel;

public abstract class State {

    protected ATM atm;
    protected Keypad keypad;
    protected Display display;
    protected CardReader cardReader;

    public State(ATM atm) {
        this.atm = atm;
    }


    public abstract void readAndValidateCard();

    public abstract void readAndValidatePin();

    public abstract void ejectCard();

    public abstract void displayError();

    public abstract void insertCard(Card card);
}
