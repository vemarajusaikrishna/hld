package lld.food.state;

import lld.billing.model.Order;

public class Completed extends OrderState {
    public Completed(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        return false;
    }

    @Override
    public boolean assignDeliveryPartner() {
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        return false;
    }

    @Override
    public void confirmDelivery() {

    }

    @Override
    public void generateInvoice() {

    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void getFeedbackAndRating() {
    }
}
