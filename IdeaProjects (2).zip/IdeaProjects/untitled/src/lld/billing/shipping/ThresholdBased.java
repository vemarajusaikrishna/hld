package lld.billing.shipping;

import lld.billing.model.Purchase;

public class ThresholdBased  extends ShippingCostHandler {
    private double basicCost;
    @Override
    public double getShippingCost(Purchase purchase) {
        return purchase.getOrderVale()>500?0.0:;
    }
}
