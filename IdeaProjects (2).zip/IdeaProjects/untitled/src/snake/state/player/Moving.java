package snake.state.player;

import snake.Player;

public class Moving extends PlayerState{
    @Override
    public void rollDice(Player player) {
        System.out.println("Already dice rolled.");
    }

    @Override
    public void move(Player player,int spaces) {
        System.out.println("Player is moving now.");
        player.move(spaces);
        if(player.hasWon()){
            player.setPlayerState(new Win());
        }
        else {
            player.setPlayerState(new Idle());
        }
    }

    @Override
    public void pause(Player player) {
        player.setPlayerState(new PauseState());
    }

    @Override
    public void resume(Player player) {
        System.out.println("Game is already active.");
    }

    @Override
    public void exitGame(Player player) {
        player.setPlayerState(new Exited());

    }
}
