import java.util.Stack;

public class StockGroups {



    private int[] nearestGreater(int start , int end,int dx,int[] res,int[] nums)
    {

        Stack<Integer> stack = new Stack();

        for(int i = start ; i != end ;i = i+dx)
        {
              while(!stack.isEmpty() && nums[stack.peek()] <= nums[i])
              {
                  System.out.println(stack.peek());

                  stack.pop();
              }
              if(stack.isEmpty())
              {
                  res[i]= start > end ?nums.length:-1;
              }
              else
              {
                  res[i] = stack.peek();
              }
              stack.push(i);
        }
        return res;

    }

    public int[] count(int[] nums)
    {
        int[] right = new int[nums.length];
        nearestGreater(nums.length-1 , -1,-1,right, nums);

        int[] left = new int[nums.length];
        nearestGreater(0, nums.length,+1,left, nums);

        int[] ans = new int[nums.length];
        for(int i =0 ; i < nums.length ;i++)
        {
            ans[i] = right[i]-left[i]-1;
        }
        /*
        int[] countSubarrays(int[] arr) {
    Stack<Integer> stack = new Stack<>();
    int[] ans = new int[arr.length];
    for(int i = 0; i < arr.length; i++) {
      while(!stack.isEmpty() && arr[stack.peek()] < arr[i]) {
        ans[i] += ans[stack.pop()];
      }
      stack.push(i);
      ans[i]++;
    }
     stack.clear();
    int[] temp = new int[arr.length];
     for(int i = arr.length - 1; i >= 0; i--) {
      while(!stack.isEmpty() && arr[stack.peek()] < arr[i]) {
        int idx = stack.pop();
        ans[i] += temp[idx];
        temp[i] += temp[idx];
      }
      stack.push(i);
      temp[i]++;
    }
    return ans;
  }
        */


        return ans;


    }
}
