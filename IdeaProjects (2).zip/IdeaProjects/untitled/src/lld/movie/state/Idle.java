package lld.movie.state;

public class Idle {

    //user search movies ,theaters
    //create booking object
}
