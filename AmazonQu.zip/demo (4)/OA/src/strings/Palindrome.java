package strings;

public class Palindrome {
    public int minSwaps(int[] nums) {


        int left = 0, right = nums.length-1;
        int swaps = 0;
        int zeros =0, ones = 0;
        while(left <= right)
        {
            int l = nums[left];
            int r = nums[right];

            if(l == 0)
                zeros++;
            else
                ones++;

            if(left!=right)
            {
                if(r == 0)
                    zeros++;
                else
                    ones++;
            }

            if(l!=r)
            {
                swaps++;
            }

            left++;
            right--;
        }

        //if count of both is odd, then pallindrome is not possible
        if(zeros%2 != 0 && ones%2!=0)
        {
            return -1;
        }

        //we can simply count number of mismatchs and return (number of mismatchs)/2
        return (swaps+1)/2;
    }
}
