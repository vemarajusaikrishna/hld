package lld.food.model.cuisine;

public abstract class Cuisine {

    private String name;

    public Cuisine(String name) {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
