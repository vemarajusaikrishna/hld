package snake.notification;

public abstract class Observer {


   public abstract void notify(int jumpedAt, int from, int to);
}
