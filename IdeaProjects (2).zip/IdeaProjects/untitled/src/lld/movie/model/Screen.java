package lld.movie.model;

public class Screen {
    private String screenId;
    private String theaterId;
    private int seats;
}
