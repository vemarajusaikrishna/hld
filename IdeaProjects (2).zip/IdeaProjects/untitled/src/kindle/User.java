package kindle;

import java.util.List;

public class User {

    private String userid;
    private List<String> moviewishList;
    private List<User> friends;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public List<String> getMoviewishList() {
        return moviewishList;
    }

    public void setMoviewishList(List<String> moviewishList) {
        this.moviewishList = moviewishList;
    }

    public List<User> getFriends() {
        return friends;
    }

    public void setFriends(List<User> friends) {
        this.friends = friends;
    }
}
