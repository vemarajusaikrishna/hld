package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public class ServiceCharge extends TotalCostDecorator{
    private double serviceCharge;
    public ServiceCharge(TotalCost totalCost, double serviceCharge) {
        super(totalCost);
        this.serviceCharge = serviceCharge;
    }

    @Override
    public double calculateCost(Customer customer, Purchase purchase) {
        return totalCost.calculateCost(customer, purchase) + serviceCharge;
    }
}
