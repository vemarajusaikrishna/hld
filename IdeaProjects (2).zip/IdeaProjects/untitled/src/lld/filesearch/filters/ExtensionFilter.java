package lld.filesearch.filters;

import lld.filesearch.composite.Component;

public class ExtensionFilter implements Specification<Component>{
    private String extension;

    public ExtensionFilter(String extension) {
        this.extension = extension;
    }

    @Override
    public boolean isSatisfiedBy(Component item) {
        return extension.equals(extension);
    }
}
