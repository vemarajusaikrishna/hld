package parkingLot.model;

public class ParkingSlot {

    private int slotId;
    private boolean isFree;
    private Vehicle vehicle;


    public int getSlotId() {
        return slotId;
    }

    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    public boolean isFree() {
        return isFree;
    }

    public void setFree(boolean free) {
        isFree = free;
    }

    public void park(Vehicle vehicle) {
        this.vehicle = vehicle;
        setFree(false);
    }

    public void unPark() {
        this.vehicle = null;
        setFree(true);
    }
}
