package fullfillmentcenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class GetMinConnectionCost {

    public static int[] getMinConnectionCost(int[] warehouseCapacity, int[][] hubs) {
        int n = warehouseCapacity.length;
        int[] prefix = new int[n];
        int sum=0;
        for (int i=0;i<n;i++) {
            sum+=warehouseCapacity[i];
            prefix[i] = sum;
        }
        int[] ans = new int[hubs.length];
        int i=0;
        for (int[] hub: hubs) {
            Arrays.sort(hub); //O(1) since only 2 elements
            ans[i++] = computeCost(warehouseCapacity, prefix, hub[0], hub[1], n);
        }
        return ans;
    }


    private static int computeCost(int[] warehouseCapacity, int[] prefix, int hubA, int hubB, int n) {
        int res = 0;
        if (hubA>=2)
            res += ((hubA-1)*warehouseCapacity[hubA-1] - prefix[hubA-2]);
        if (hubA != hubB && hubB>=2)
            res += ((hubB-hubA-1)*warehouseCapacity[hubB-1] - (prefix[hubB-2]-prefix[hubA-1]));
        if (hubB!=n)
            res+= ((n-hubB-1)*warehouseCapacity[n-1] - (prefix[n-2]-prefix[hubB-1]));
        return res;
    }
}

/*public static void main(String[] args){
int[] capacity = {0, 2, 5, 9, 12, 18};
int q = 2;
int[][] additionalHubs = {{2,5},{1,3}};
List results = new ArrayList<>();


    for(int[] hubs: additionalHubs){
        List<Integer> hub = new ArrayList<>();
        hub.add(hubs[0]-1);
        hub.add(hubs[1]-1);

        Collections.sort(hub);//O(1)- as there will always be 2 elements.
        hub.add(capacity.length-1);
        results.add(computeCost(hub,capacity));

    }
    System.out.println("Results: "+ results);
}

private static Integer computeCost(List<Integer> hubs, int[] capacity) {
    System.out.println(hubs);
    int totalCost = 0;
    for(int i=0;i<capacity.length;i++){
        int minCost = Integer.MAX_VALUE;
        for(int hub: hubs){
            if(hub>=i){
                minCost=Math.min(minCost, capacity[hub]-capacity[i]);
            }
        }
        totalCost+=minCost;
    }
    return totalCost;
}*/
