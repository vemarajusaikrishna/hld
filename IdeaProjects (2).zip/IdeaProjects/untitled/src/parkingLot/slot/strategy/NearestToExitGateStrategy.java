package parkingLot.slot.strategy;

import parkingLot.model.ParkingSlot;

public class NearestToExitGateStrategy implements ParkingStrategy{
    @Override
    public ParkingSlot getParkingSpot() {
        return null;
    }
}
