package lld.billing.discounts;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public class ProductCategory extends DiscountHandler {

    public ProductCategory() {
    }
    @Override
    public double handle(Customer customer, Purchase purchase) {
        double nextAppliedDiscount = this.getNextDiscountHandler() != null ? this.getNextDiscountHandler().handle(customer, purchase):0.0;
        double currentAppliedDiscount = purchase.getProductCategory().getDiscount();
        return Math.max(currentAppliedDiscount,nextAppliedDiscount);
    }
}
