package lld.ride.servicee.locationservice;

import lld.ride.model.Address;
import lld.ride.model.Location;

import java.util.List;

public class GoogleMapsLocationService implements LocationService {
    @Override
    public Location getCurrentLocation() {
        return null;
    }

    @Override
    public double calculateDistance(Location loc1, Location loc2) {
        return 0;
    }

    @Override
    public double calculateEta(Location loc1, Location loc2) {
        return 0;
    }

    @Override
    public Location geoCoding(Address address) {
        return null;
    }

    @Override
    public String reverseGeoCoding(Location location) {
        return "";
    }
}
