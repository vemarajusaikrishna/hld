package snake.state.player;

import snake.Player;

public abstract class PlayerState {

    public abstract void rollDice(Player player);
    public abstract void move(Player player, int spaces);
    public abstract void pause(Player player);
    public abstract void resume(Player player);
    public abstract void exitGame(Player player);
}
