package cricBuzz.observer;

public class BowlingScoreCardUpdator implements ScoreCardUpdator {


}
