package lld.movie.event;

public interface Event {

     String eventType();
     String payload();
}
