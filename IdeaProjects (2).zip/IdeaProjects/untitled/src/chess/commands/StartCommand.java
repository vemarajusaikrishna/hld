package chess.commands;

public class StartCommand implements Command{
    @Override
    public void execute() {

    }
}
