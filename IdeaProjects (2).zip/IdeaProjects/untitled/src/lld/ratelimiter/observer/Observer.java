package lld.ratelimiter.observer;

public interface Observer {
   public void update(String userId,String endpoint);
}
