package lld.food.model;

import lld.food.state.OrderState;
import lld.food.state.Placed;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public class Order {

    private String orderId;
    private LocalDateTime lastUpdatedOn;
    private LocalDateTime createdOn;
    private LocalDateTime preparedOn;
    private String userId;
    private String restaurantId;
    private String deliveryPartnerId;
    private List<OrderItem> orderItems;
    private TrackingDetails trackingDetails;
    private OrderState orderState;
    private boolean isPriority;
    private String cancellationReason;
    private Review review;

    public Order(String orderId, OrderState orderState) {
        this.orderId = UUID.randomUUID().toString();
        this.orderState = new Placed(this);
    }
}
