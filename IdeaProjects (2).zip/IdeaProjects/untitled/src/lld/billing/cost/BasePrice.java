package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public class BasePrice implements TotalCost{

    public BasePrice() {

    }


    @Override
    public double calculateCost(Customer customer, Purchase purchase) {
        return purchase.getOrderVale();
    }
}
