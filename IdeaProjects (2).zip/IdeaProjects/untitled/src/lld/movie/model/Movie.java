package lld.movie.model;

public class Movie {

    private String movieId;
    private String movieName;
    private String language;
    private float duration;
    private String genere;
    private String hero;
    private String heroine;
    private String summary;
}
