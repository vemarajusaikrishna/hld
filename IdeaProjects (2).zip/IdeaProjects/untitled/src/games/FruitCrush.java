package games;

import java.util.*;

public class FruitCrush {


    public static int minFruitsLeft(int[] nums) {
        HashMap<Integer, Integer> map = new HashMap<>();

        for (int num : nums) map.put(num, map.getOrDefault(num, 0) + 1);
        PriorityQueue<Integer> maxHeap = new PriorityQueue<>(Collections.reverseOrder());
        for (int fr : map.values()) maxHeap.offer(fr);
        while (maxHeap.size() > 1) {

            int one = maxHeap.poll();
            int two = maxHeap.poll();

            if(one > 1)
            {
                maxHeap.offer(one-1);
            }
            if(two > 1)
            {
                maxHeap.offer(two-1);
            }
        }

        return maxHeap.poll();
    }



    public static void main(String[] args) {
        int[] fruits = new int[]{2 ,2,2,2,1,5,5,7,8,9,10};

        System.out.println("Minimum possible number of fruits left: " + minFruitsLeft(fruits));
    }
}


