public class WeightLiftingEquipment {
}
