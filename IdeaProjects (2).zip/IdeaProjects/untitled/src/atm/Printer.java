package atm;

public class Printer {

    public void printReceipt(TransactionDetails trnasctionDetails) {
        System.out.print("Printing transactionDetails.....");
        System.out.print(trnasctionDetails.toString());
        //printing logic needs to e added
        System.out.print("Please collect the receipt.");

    }
}
