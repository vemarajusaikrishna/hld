package snake.state.game;

import snake.Game;

public class ActiveState implements GameState{
    @Override
    public void initialize(Game game) {
        System.out.println("Game setup already completed.It is in running.");
    }

    @Override
    public void pause(Game game) {
         game.setGameState(new PausedState());
         game.pause();
    }

    @Override
    public void resume(Game game) {
        System.out.println("It is in running.");
    }

    @Override
    public void stop(Game game) {
       game.setGameState(new StopState());
       game.exit();
    }

    @Override
    public void reset(Game game) {
        game.setGameState(new ResetState());
        game.reset();
    }

    @Override
    public void start(Game game) {
       //write the logic to take each player turn
        game.run();

    }
}
