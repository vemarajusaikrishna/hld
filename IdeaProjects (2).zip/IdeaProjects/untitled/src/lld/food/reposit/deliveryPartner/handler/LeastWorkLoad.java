package lld.food.reposit.deliveryPartner.handler;

import lld.food.model.DeliveryConfiguration;
import lld.food.model.DeliveryPartner;
import lld.food.model.Location;

import java.util.List;
import java.util.TreeMap;

public class LeastWorkLoad extends OptimalDeliveryPartnerHandler{
    public LeastWorkLoad(OptimalDeliveryPartnerHandler nextHandler) {
        super(nextHandler);
    }

    @Override
    public TreeMap<String,Float> getOptimalScore(List<DeliveryPartner> deliverPartners, Location restaurant, Location customer, DeliveryConfiguration weight) {
        return null;
    }
}
