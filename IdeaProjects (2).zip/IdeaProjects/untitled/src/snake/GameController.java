package snake;

import snake.commands.player.GameCommandFactory;

public class GameController {

    private GameCommandFactory gameCommandFactory;
    private snake.commands.game.GameCommandFactory gameCommandFactory;
    private Game game;

    public GameController(GameCommandFactory playerCommandFactory, snake.commands.game.GameCommandFactory gameCommandFactory) {
        this.gameCommandFactory = new GameCommandFactory();
        this.gameCommandFactory = new snake.commands.game.GameCommandFactory();
        this.game = new Game();
    }

    public void pressPauseButton(){
        gameCommandFactory.getCommand(1).execute();

    }
}
