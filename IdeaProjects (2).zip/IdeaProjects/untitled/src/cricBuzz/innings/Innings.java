package cricBuzz.innings;

import cricBuzz.Team;

import java.util.List;

public class Innings {

    Team battingTeam;
    Team bowlingTeam;
    List<Over> overs;


    public void startInnings()
    {

    }
}
