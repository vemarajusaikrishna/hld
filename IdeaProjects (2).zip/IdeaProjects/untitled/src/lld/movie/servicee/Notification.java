package lld.movie.servicee;

import lld.movie.chain.DeliveryChannelHandler;
import lld.movie.chain.EmailChannel;
import lld.movie.chain.SMSDeliveryChannel;

public class Notification {
    public Notification(DeliveryChannelHandler deliveryChannelHandler) {
        this.deliveryChannelHandler = new SMSDeliveryChannel(new EmailChannel(null));
    }

    private DeliveryChannelHandler deliveryChannelHandler;

    public void sendNotification(String message,User user){
          deliveryChannelHandler.sendNotification(message,user);
    }

}
