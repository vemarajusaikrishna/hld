package lld.billing.model;

public class Item {
}
