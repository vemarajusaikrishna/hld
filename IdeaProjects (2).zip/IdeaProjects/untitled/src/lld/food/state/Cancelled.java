package lld.food.state;

import lld.billing.model.Order;

public class Cancelled extends OrderState{
    public Cancelled(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        System.out.println("Order already restaurant");

    }

    @Override
    public boolean assignDeliveryPartner() {
        System.out.println("Delivery partner already assigned");
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        System.out.println("Tracking details already generated");
        return false;
    }

    @Override
    public void confirmDelivery() {
        System.out.println("Order cancelled.");
    }

    @Override
    public void generateInvoice() {
        System.out.println("Already genrated.");
    }

    @Override
    public void getFeedbackAndRating() {
        //write logic to get feedback from user
    }
}
