package lld.billing.model.paymentmethods;

public class UPI extends PaymentMethod{
}
