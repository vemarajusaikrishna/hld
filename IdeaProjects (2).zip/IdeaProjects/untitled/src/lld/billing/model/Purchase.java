package lld.billing.model;

import lld.billing.model.paymentmethods.PaymentMethod;
import lld.billing.model.productcategory.ProductCategory;

public class Purchase {
    private String cupon;
    private PaymentMethod paymentMethod;
    private double orderVale;
    private ProductCategory productCategory;

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public double getOrderVale() {
        return orderVale;
    }

    public void setOrderVale(double orderVale) {
        this.orderVale = orderVale;
    }

    public ProductCategory getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(ProductCategory productCategory) {
        this.productCategory = productCategory;
    }

    public String getCupon() {
        return cupon;
    }

    public void setCupon(String cupon) {
        this.cupon = cupon;
    }
}
