package lld.ratelimiter.algorithms.fixedWIndow;

import lld.ratelimiter.algorithms.RateLimitingAlgorithm;

import java.util.HashMap;
import java.util.Map;

public class FixedWindow extends RateLimitingAlgorithm {

    private int maxRequestsPerInterval;
    private long intervalSizeInMillis;
    private Map<String, RequestBucket> clientBuckets;

    public FixedWindow(int maxRequestsPerInterval, long intervalSizeInMillis, Map<String, RequestBucket> clientBuckets) {
        this.maxRequestsPerInterval = maxRequestsPerInterval;
        this.intervalSizeInMillis = intervalSizeInMillis;
        this.clientBuckets = new HashMap<>();
    }

    public boolean allow(String clientId){

        long currentTime = System.currentTimeMillis();
        //check if the client having bucket or not

        clientBuckets.putIfAbsent(clientId,new RequestBucket(0,currentTime));
        RequestBucket requestBucket  = clientBuckets.get(clientId);

        //clean bucket
        if(currentTime - requestBucket.getStartTime() >= intervalSizeInMillis){
            //reset bucket
            requestBucket.setStartTime(currentTime);
            requestBucket.setCurrentRequestCount(0);
        }
        if(requestBucket.getCurrentRequestCount() < maxRequestsPerInterval){
             requestBucket.setCurrentRequestCount(requestBucket.getCurrentRequestCount()+1);
             return true;
        }
        return false;
    }

    @Override
    public boolean handleRequest(String userId) {
       return allow(userId);
    }
}

