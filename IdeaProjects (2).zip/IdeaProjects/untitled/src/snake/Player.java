package snake;

import snake.notification.Observer;
import snake.state.player.PlayerState;

public class Player extends Observer {

    private String name;
    private int id;
    private int currentLocation;
    private PlayerState playerState;
    private Dice dice;
    private Board1 board;

    public Player(String name, int id, int currentLocation, PlayerState playerState, Dice dice, Board board) {
        this.name = name;
        this.id = id;
        this.currentLocation = currentLocation;
        this.playerState = playerState;
        this.dice = new Dice(2);
        this.board = new Board1();
    }

    public void pause(){
       playerState.pause(this);
    }

    public void resume(){
        playerState.resume(this);
    }

    public void exit() {
        playerState.exitGame(this);
    }
    public void rollDiceAction(){
        playerState.rollDice(this);
    }
    public void moveAction(int spaces){
        playerState.move(this,spaces);
    }

    public PlayerState getPlayerState() {
        return playerState;
    }

    public void setPlayerState(PlayerState playerState) {
        this.playerState = playerState;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(int currentLocation) {
        this.currentLocation = currentLocation;
    }

    @Override
    public void notify(int jumpedAt,int from,int to) {
      if(jumpedAt > to) {
          System.out.println("Snake bitten at :"+jumpedAt);
      }
      else if(jumpedAt < to) {
          System.out.println("ladder climbed at :"+jumpedAt);
      }
        System.out.println("current position : "+to);
        System.out.println("previous position : "+from);
    }

    public void move(int spaces){
        currentLocation += spaces;
        currentLocation =  board.getLandingPosition(currentLocation);

    }
    public boolean hasWon(){
        return currentLocation >= board.getFinalPosition();
    }
    public int rollDice(){
       return dice.rollDice();
    }
    public void takeTurn(){
        playerState.rollDice(this);
    }

}
