package lld.ride.servicee.locationservice.adapter;

import lld.ride.model.Address;
import lld.ride.model.Location;
import lld.ride.servicee.locationservice.GoogleMapsLocationService;

import java.util.List;

public class GoogleMapsAdapter implements LocationServiceAdapter {

    private GoogleMapsLocationService googleMapsLocationService;

    public GoogleMapsAdapter(GoogleMapsLocationService googleMapsLocationService) {
        this.googleMapsLocationService = googleMapsLocationService;
    }
    @Override
    public Location getCurrentLocation() {
        return null;
    }

    @Override
    public double calculateDistance(Location loc1, Location loc2) {
        return 0;
        //use distance API
    }

    @Override
    public double calculateEta(Location loc1, Location loc2) {
        return 0;
        //use directionAPI
    }

    @Override
    public Location geoCoding(Address address) {
        return null;
    }

    @Override
    public String reverseGeoCoding(Location location) {
        return "";
    }
}
