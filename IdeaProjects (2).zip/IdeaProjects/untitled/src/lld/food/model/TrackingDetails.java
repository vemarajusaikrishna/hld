package lld.food.model;

import lld.food.state.OrderState;

import java.time.LocalDateTime;
import java.time.LocalTime;

public class TrackingDetails {

    private String trackingId;
    private LocalTime deliveryStartTime;
    private LocalTime deliveryEndTime;
    private LocalTime eta;
    private Location deliveryPartnerLocation;
    private Location restaurantLocation;
}
