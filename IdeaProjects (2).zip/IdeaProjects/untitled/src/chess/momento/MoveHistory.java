package chess.momento;

import java.util.Stack;

public class MoveHistory {

   private Stack<MoveMomento> moveHistory = new Stack<>();

   public void saveMove(MoveMomento moveMomento)
   {
       moveHistory.push(moveMomento);
   }

   public MoveMomento getLastMove() {
      return  moveHistory.pop();
   }

   public Stack<MoveMomento> getMoveHistory() {
       return moveHistory;
   }

   public void replayAllMoves() {
       for(int i =0 ; i < moveHistory.size() ;i++ ) {
           moveHistory.get(i).toString();
       }
   }

}
