package lld.goodreads;

import lld.goodreads.model.Book;
import lld.goodreads.model.Pair;
import lld.goodreads.model.User;

import java.util.*;
import java.util.stream.Collectors;

public class BookLookUpStrategyImpl extends BookLookupStrategy{



    @Override
    public List<Book> getTopUserBooksThatFriendsHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity) {
        Map<String ,Integer> popularityCount = new HashMap<>();
        for(String  bookId : users.get(userId).getBooks()){

            for(String friend : users.get(userId).getFriends()){

                if(users.get(friend).getBooks().contains(bookId)){
                    popularityCount.put(bookId,popularityCount.getOrDefault(bookId,0)+1);
                }
            }
        }

       return   popularityCount.entrySet()
                .stream()
                .sorted(Map.Entry.comparingByValue())
                .limit(capacity)
                .map(entry -> books.get(entry.getKey()))
                .collect(Collectors.toList());
    }

    @Override
    public List<Book> getTopUserBooksThatNetworkHasRead(Map<String, Book> books, Map<String, User> users, String userId, int capacity, int networkDepth) {
     Queue<Pair> queue = new LinkedList<>();
     Map<String ,Integer> frequencyMap = new HashMap<>();
     Set<String> visited = new HashSet<>();

     visited.add(userId);
     queue.add(new Pair(userId,1));

     while(!queue.isEmpty()){

         Pair current = queue.poll();
         String user = current.getUser();
         int depth = current.getDepth();

         for(String bookId : users.get(user).getBooks()){
             frequencyMap.put(bookId, frequencyMap.getOrDefault(bookId,0)+1);
         }

         for(String friend : users.get(userId).getFriends()){
             if(!visited.contains(friend)){
                 queue.add(new Pair(friend,depth+1));
             }
         }


     }

     return frequencyMap.entrySet()
             .stream()
             .sorted(Map.Entry.comparingByValue())
             .limit(capacity)
             .map(entry -> books.get(entry.getKey()))
             .collect(Collectors.toList());

    }
}
