package parkingLot.slot.strategy;

import parkingLot.model.ParkingSlot;

public class NearestFloorStrategy implements ParkingStrategy{
    @Override
    public ParkingSlot getParkingSpot() {
        return null;
    }

}
