package atm;

import atm.handler.FiveHundredRupee;
import atm.handler.TwoThousandRupee;
import atm.states.Idle;
import atm.states.State;

import java.util.HashMap;
import java.util.Map;

public class ATM {

    private Keypad keypad;
    private CardReader cardReader;
    private CashDispenser cashDispenser;
    private CashStorageBox cashStorageBox;
    private Printer printer;
    private Display display;
    private State state;
    private Map<Integer,State> transactionMenu;
    private Card insertedCard ;

    public Card getInsertedCard() {
        return insertedCard;
    }

    public void setInsertedCard(Card insertedCard) {
        this.insertedCard = insertedCard;
    }

    public ATM() {
        this.keypad = new Keypad();
        this.cardReader = new CardReader();
        this.cashStorageBox = new CashStorageBox();
        this.cashDispenser = new CashDispenser(cashStorageBox);
        this.printer = new Printer();
        this.display = new Display();
        this.state = new Idle(this);
        this.transactionMenu = new HashMap<>();
        initializeHandlers();
    }

    private void initializeHandlers() {

    }

    public void addToMenu(int input , State state) {
        transactionMenu.put(input,state);
    }

    public void removeFromMenu(int input , State state)
    {
        if(!transactionMenu.containsKey(input))
            return;
        transactionMenu.remove(input,state);
    }

    public State getFromMenu(int input , State state) {
        transactionMenu.get(input);
    }

    public State getState() {
        return state;
    }

    public void setState(State state) {
        this.state = state;
    }

    public Keypad getKeypad() {
        return keypad;
    }

    public void setKeypad(Keypad keypad) {
        this.keypad = keypad;
    }

    public CardReader getCardReader() {
        return cardReader;
    }

    public void setCardReader(CardReader cardReader) {
        this.cardReader = cardReader;
    }

    public CashDispenser getCashDispenser() {
        return cashDispenser;
    }

    public void setCashDispenser(CashDispenser cashDispenser) {
        this.cashDispenser = cashDispenser;
    }

    public CashStorageBox getCashStorageBox() {
        return cashStorageBox;
    }

    public void setCashStorageBox(CashStorageBox cashStorageBox) {
        this.cashStorageBox = cashStorageBox;
    }

    public Printer getPrinter() {
        return printer;
    }

    public void setPrinter(Printer printer) {
        this.printer = printer;
    }

    public Display getDisplay() {
        return display;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }
}
