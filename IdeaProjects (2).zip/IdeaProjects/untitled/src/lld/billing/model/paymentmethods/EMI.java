package lld.billing.model.paymentmethods;

public class EMI extends PaymentMethod{
}
