package atm;

import java.util.Scanner;

public class Keypad {

    private Scanner scanner = new Scanner(System.in);

    public String getInput() {
        System.out.println("Enter input : ");
        return scanner.nextLine();
    }
}
