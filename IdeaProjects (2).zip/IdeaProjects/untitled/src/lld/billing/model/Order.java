package lld.billing.model;

public class Order {
}
