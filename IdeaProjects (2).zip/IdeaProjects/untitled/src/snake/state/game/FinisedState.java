package snake.state.game;

import snake.Game;

public class FinisedState implements GameState{
    @Override
    public void initialize(Game game) {

    }

    @Override
    public void pause(Game game) {

    }

    @Override
    public void resume(Game game) {

    }

    @Override
    public void stop(Game game) {

    }

    @Override
    public void reset(Game game) {

    }

    @Override
    public void start(Game game) {

    }
}
