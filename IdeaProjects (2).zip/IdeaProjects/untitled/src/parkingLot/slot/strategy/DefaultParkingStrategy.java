package parkingLot.slot.strategy;

import parkingLot.model.ParkingSlot;

public class DefaultParkingStrategy implements ParkingStrategy{
    @Override
    public ParkingSlot getParkingSpot() {
        return null;
    }
}
