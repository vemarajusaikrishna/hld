package lld.ride.servicee.states;

import lld.ride.model.Location;

public abstract class RideState {

    public abstract void searchDriver(Location source, Location dropOff);
    public abstract void generateTrackingDetailsAndOtp();
    public abstract void updateTrackingDetails();
    public abstract void trackRide(String rideId);
    public abstract void validateOtp(int opt);
    public abstract void completePayment();
    public abstract void collectFeedBackAndRating();
    public abstract void cancel();
}
