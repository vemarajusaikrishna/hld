package chess;

import chess.model.enums.PieceColour;

public class Player {
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public PieceColour getPieceColour() {
        return pieceColour;
    }

    public void setPieceColour(PieceColour pieceColour) {
        this.pieceColour = pieceColour;
    }

    private int id;
    private PieceColour pieceColour;

    public Player(int id, PieceColour pieceColour) {
        this.id = id;
        this.pieceColour = pieceColour;
    }
}
