package lld.ratelimiter.algorithms.tokenbucket;

import lld.ratelimiter.algorithms.RateLimitingAlgorithm;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

public class Algorithm extends RateLimitingAlgorithm {

    private ConcurrentHashMap<String, ConcurrentHashMap<String,Bucket>> buckets;
    private Map<String,Bucket> bucketHttpMethod = new HashMap<>();
    private ReentrantLock lock = new ReentrantLock();
    public Algorithm(ConcurrentHashMap<String, ConcurrentHashMap<String, Bucket>> buckets) {
        this.buckets = new ConcurrentHashMap<>();
    }

    public void configureBucket(String httpMethod,int burstWindow,int refillRatePerSecond){
        lock.lock();
        try{
              bucketHttpMethod.put(httpMethod,new Bucket(refillRatePerSecond,burstWindow));
        }
        finally{
            if(lock.isLocked())
                lock.unlock();
        }
    }

    public boolean isAllow(String userId,String httpMethod){

        buckets.putIfAbsent(userId,new ConcurrentHashMap<>());
        buckets.get(userId).putIfAbsent(httpMethod,bucketHttpMethod.get(httpMethod));
        Bucket bucket = buckets.get(userId).get(httpMethod);
        return bucket.isAllowed();
    }

    @Override
    public boolean handleRequest(String userId) {

        return isAllow(userId,null);
    }
}
