package lld.ratelimiter.algorithms.fixedWIndow;

public class RequestBucket{

    private int currentRequestCount;
    private long startTime;

    public RequestBucket(int currentRequestCount, long startTime) {
        this.currentRequestCount = currentRequestCount;
        this.startTime = startTime;
    }

    public int getCurrentRequestCount() {
        return currentRequestCount;
    }

    public void setCurrentRequestCount(int currentRequestCount) {
        this.currentRequestCount = currentRequestCount;
    }

    public long getStartTime() {
        return startTime;
    }

    public void setStartTime(long startTime) {
        this.startTime = startTime;
    }
}
