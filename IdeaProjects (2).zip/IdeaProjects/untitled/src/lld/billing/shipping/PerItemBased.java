package lld.billing.shipping;

import lld.billing.model.Purchase;

public class PerItemBased extends ShippingCostHandler {
    @Override
    public double getShippingCost(Purchase purchase) {
        return 0;
    }
}
