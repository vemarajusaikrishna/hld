package chess;

import java.util.List;
import java.util.Map;

public abstract class Observable {

    Map<Integer,BoardListener> observers ;

    public void subscribeBoardListener(BoardListener boardListener)
    {
           observers.put(boardListener);
    }

    public void unsubscribeBoardListener(BoardListener boardListener){
        for(BoardListener observers : observers) {

        }
    }
}
