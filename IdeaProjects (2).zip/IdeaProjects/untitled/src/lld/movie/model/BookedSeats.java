package lld.movie.model;

public class BookedSeats {

    private String bookingId;
    private String seatId;
}
