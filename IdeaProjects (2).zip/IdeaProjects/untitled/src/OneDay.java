//public class OneDay {
//
//    A student is preparing for a test from amazon academy for a scholarship.
//
//    The student is required to completly read n chapters (which is the length of the pages array) for the test where the ith chapter has pages[i] number of pages. The chapters are read in increasing order of the index. Each day the student can either read till the end of a chapter or at the most x pages, whichever is minimum. The number of pages remaining to read decreases by x in the later case.
//
//    For example, if pages = [5,3,4]  days = 4 and x = 4 (x is the output the program needs to return).
//
//    Day 1: The student reads A pages of the first chapter - pages remaining = [1, 3, 4]
//    Day 2: The student can only read till the end of the first chapter - pages remaining = [0, 3, 4]
//    Day 3: The student can only read till the end of the chapter x = 4 pages, since 3<4, the student reads till the end of the chapter 2- pages remaining = [0, 0, 4]
//    Day 4: The student reads all the 4 pages of the last chapter - pages remaining = [0, 0, 0]
//
//    The test will be given in [days] number of days from now. Find the minimum number of the pages, x, which the student should read each day to finish all pages of all chapters within days number of days. If it is not possible to finish these chapters in days number of days, return -1.
//}
