package cricBuzz;

import java.util.List;
import java.util.Queue;

public class Team {

    private String name;
    private Queue<Player> players;
    private List<Player> onBenchPlayers;

}
