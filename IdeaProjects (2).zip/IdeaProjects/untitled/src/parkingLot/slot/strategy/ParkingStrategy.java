package parkingLot.slot.strategy;

import parkingLot.model.ParkingSlot;

public interface  ParkingStrategy {

    public ParkingSlot getParkingSpot();

}
