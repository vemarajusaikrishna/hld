package strings;

import java.util.Stack;

public class Question2 {
    public static String getSpecialString(String input){

        if(input.length() == 0) return input;
        Stack<Character> stack = new Stack();

        char[] inputArray = input.toCharArray();
        if(inputArray.length == 1){
            if(inputArray[0] == 'z') return "-1";
            else{
                inputArray[0] = (char)(inputArray[0] + 1);
                return String.valueOf(inputArray);
            }
        }

        for(int i = 0; i < inputArray.length; i++){
            if(!stack.isEmpty() && stack.peek() == inputArray[i]){
                stack.push(inputArray[i]);
                break;
            }
            stack.push(inputArray[i]);
        }

        return getLexicographicalNextString(stack, inputArray.length);
    }

    private static char nextCharacter(char c, char prev){
        if(prev == ((char) (c + 1))){
            return (char) (1 + prev);
        }

        return (char) (1 + c);
    }

    private static String getLexicographicalNextString(Stack<Character> stack, int n){
        char lastChar = stack.pop();

        while(!stack.isEmpty() && (lastChar == 'z' || (lastChar == 'y' && stack.peek() == 'z'))){
            lastChar = stack.pop();
        }

        if(lastChar == 'z') return "-1";

        stack.push(nextCharacter(lastChar, stack.peek()));

        StringBuilder sb = new StringBuilder();
        while(!stack.isEmpty()){
            sb.append(stack.pop());
        }

        sb.reverse();

        while(sb.length() < n){
            if(sb.charAt(sb.length()-1) > 'a'){
                sb.append('a');
            }
            else{
                sb.append('b');
            }
        }

        return sb.toString();
    }

    public static void main(String[] args) {
        System.out.println("abcd: " + getSpecialString("abcd"));
        System.out.println("aacd: " + getSpecialString("aacd"));
        System.out.println("abbscd: " + getSpecialString("abbscd"));
        System.out.println("aaaa: " + getSpecialString("aaaa"));
        System.out.println("zzabb: " + getSpecialString("zzabb"));
        System.out.println("abczz: " + getSpecialString("abczz"));
        System.out.println("abcc: " +  getSpecialString("abcc"));
        System.out.println("abccss: " + getSpecialString("abccss"));
        System.out.println("zyx: " + getSpecialString("zyx"));
        System.out.println("abbd: " + getSpecialString("abbd"));
        System.out.println("abccdeaaa: " + getSpecialString("abccdeaaa"));
        System.out.println("zyxwvutstuvwxyz: " + getSpecialString("zyxwvutstuvwxyz"));
        System.out.println("zyz: " + getSpecialString("zyz"));
        System.out.println("zyxz: " + getSpecialString("zyxz"));
        System.out.println("zyzyzyz: " + getSpecialString("zyzyzyz"));
    }
}
