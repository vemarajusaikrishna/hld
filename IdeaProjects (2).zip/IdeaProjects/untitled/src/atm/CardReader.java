package atm;

public class CardReader {

    public boolean readCard(Card card)
    {
        System.out.println("Reading card");
        //card reading logic
        return true;

    }

    public boolean acceptCard(Card card)
    {
        System.out.println("Inserting card");
        //card reading logic
        return true;

    }

    public void releaseCard()
    {
        System.out.println("releasing card ...");

    }
}
