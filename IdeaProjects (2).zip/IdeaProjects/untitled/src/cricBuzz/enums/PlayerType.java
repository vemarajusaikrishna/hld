package cricBuzz.enums;

public enum PlayerType {

    BATSMAN,
    BOWLER,
    ALL_ROUNDER,
    CAPTAIN,
    WICKET_KEEPER;
}
