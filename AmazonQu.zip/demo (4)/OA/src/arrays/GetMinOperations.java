package arrays;

import java.util.PriorityQueue;

public class GetMinOperations {

    public static void main(String[] args) {
        // Example weights and distances
        int[] weights = { 3,6,5,1 };
        int[] distance = { 4,3,2,1 };

        int ops = calculateOperations(weights, distance);
        System.out.println(ops);
    }

    public static int calculateOperations(int[] weights, int[] distance) {
        PriorityQueue<Triple> arr = new PriorityQueue<>((a, b) -> {
            if (a.weight != b.weight) {
                return Integer.compare(a.weight, b.weight);
            } else if (a.distance != b.distance) {
                return Integer.compare(a.distance, b.distance);
            } else {
                return Integer.compare(a.index, b.index);
            }
        });

        int n = weights.length;
        for (int i = 0; i < n; i++) {
            arr.offer(new Triple(weights[i], distance[i], i));
        }

        int ops = 0;
        Triple prev = arr.poll();
        while (!arr.isEmpty()) {
            Triple curr = arr.poll();

            int temp;
            if (curr.index > prev.index) {
                continue;
            } else {
                temp = (prev.index - curr.index) / curr.distance + 1;
                curr.index += curr.distance * temp;
            }

            prev = curr;
            ops += temp;
        }
        return ops;
    }

    static class Triple {
        int weight;
        int distance;
        int index;

        Triple(int weight, int distance, int index) {
            this.weight = weight;
            this.distance = distance;
            this.index = index;
        }
    }


}


//There are n points, the ith point initially has a weight of weight[i] and is located at position i on x-axis. In a single operation, the ith point can be moved to right by a dist[i]. Given the weight and dist find the minimum number of operations required to sort the points by their weights.
//
//
//Example:
//n=4, weight=[3,6,5,1] and dist = [4,3,2,1]
//number of operations = 1+2+2=5
//
//
//First move weights[0]=3 to 0+4 place (1move)
//Next move weights[1]=6 to 1+3 = 4 and 4+3=7 place (2moves)
//Next move weights[2]=5 to 2+2=4 and 4+2=6 place (2moves)
//
//
//Constraints:
//2 <= n <= 2 * 10^5
//1 <= wieghts[i] <= 10^9
//1 <= dist[i] <= 10^3
