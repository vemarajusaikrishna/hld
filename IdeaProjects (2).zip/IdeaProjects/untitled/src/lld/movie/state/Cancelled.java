package lld.movie.state;

public class Cancelled {
}
