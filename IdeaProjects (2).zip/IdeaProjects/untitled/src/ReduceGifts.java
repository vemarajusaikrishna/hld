import java.util.Arrays;

public class ReduceGifts {

    private static int  reduceGifts(int[] gifts,int k , int threshold)
    {

        //https://leetcode.com/discuss/interview-question/5046376/Amazon-or-OA-Apr-2024-or-Reduce-gifts-SDE2

        Arrays.sort(gifts);

        int sum =0;
        int count = 0;

        for(int i =0 ;i < gifts.length ;i++)
        {
            sum += gifts[i];
            if(sum > threshold)
            {
                sum -= gifts[i];
                count++;
            }


        }

        if (count  <= k)
        {
            return count;
        }

        return -1;


    }
}
