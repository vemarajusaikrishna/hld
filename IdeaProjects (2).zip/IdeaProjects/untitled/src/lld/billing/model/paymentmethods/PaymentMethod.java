package lld.billing.model.paymentmethods;

public abstract class PaymentMethod {

    private double discount;

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }
}
