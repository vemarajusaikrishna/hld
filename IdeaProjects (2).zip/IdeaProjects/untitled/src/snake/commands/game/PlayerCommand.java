package snake.commands.game;

import snake.Player;

public abstract class PlayerCommand {

    public abstract void execute(Player player);
}
