package cricBuzz;

public class Person {

    private String name;
    private String country;
    private String email;

}
