package lld.ride.model;

import java.util.UUID;

public class RideTracker {

    private String trackerId;
    private String rideId;
    private Location currentLocation;
    private double distanceToDestination;
    private double eta;
    private Location destination;

    public RideTracker() {
        this.trackerId = UUID.randomUUID().toString();
    }

    public String getTrackerId() {
        return trackerId;
    }


    public String getRideId() {
        return rideId;
    }

    public void setRideId(String rideId) {
        this.rideId = rideId;
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Location currentLocation) {
        this.currentLocation = currentLocation;
    }

    public double getDistanceToDestination() {
        return distanceToDestination;
    }

    public void setDistanceToDestination(double distanceToDestination) {
        this.distanceToDestination = distanceToDestination;
    }

    public double getEta() {
        return eta;
    }

    public void setEta(double eta) {
        this.eta = eta;
    }

    public Location getDestination() {
        return destination;
    }

    public void setDestination(Location destination) {
        this.destination = destination;
    }
}
