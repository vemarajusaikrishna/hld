package lld.ride.model;

public class Rider extends User{
}
