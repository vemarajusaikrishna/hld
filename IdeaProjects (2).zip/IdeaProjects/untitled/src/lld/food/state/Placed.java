package lld.food.state;


import lld.food.model.Order;

public class Placed extends OrderState {
    public Placed(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
          //check with restaurant can accept or not;
        return true;
    }

    @Override
    public boolean assignDeliveryPartner() {
        System.out.println("Order is still pending for acceptance with restaurant");
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        System.out.println("Order is still pending for acceptance with restaurant");
        return false;
    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {

    }


    @Override
    public void getFeedbackAndRating() {
        System.out.println("Order is still pending for acceptance with restaurant");
    }
}
