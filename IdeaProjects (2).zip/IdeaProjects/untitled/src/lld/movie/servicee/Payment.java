package lld.movie.servicee;

import lld.movie.factory.PaymentFactory;
import lld.movie.factory.PaymentMethod;

public class Payment {

    private PaymentFactory paymentMethodFactory;

    public Payment(PaymentFactory paymentMethodFactory) {
        this.paymentMethodFactory = paymentMethodFactory;
    }

    public void registerPaymentMethod(String paymentMethodName,Class<? extends PaymentMethod> className){
    }

    public void deregisterPaymentMethod(String paymentMethodName){

    }

   public boolean processPayment(String paymentMethod){
        //use factory to fetch paymentMethod
        return true;
    }
   public boolean refundPayment(String bookingId){
       //use factory to fetch paymentMethod
       return true;
   }
}
