package lld.movie.model;

import lld.movie.factory.PaymentMethod;

import java.time.LocalTime;

public class Payment {

    private String paymentId;
    private String bookingId;
    private float amount;
    private PaymentMethod paymentMethod;
    private PaymentStatus paymentStatus;
    private LocalTime paymentTime;
    private String transactionId;
}
