Trip LifeCycle

Requested
    searchAndAssignDriver(5km)
    cancel
DriverAssigned
    generateTrackingDetailsAndOTP(driverLocation,riderLocation);
    cancel
WaitinfForPickup
    confirmPick(otp)
    trackRide(trackingId)
    updateTrackingDetails(riderLocation,drop);
    cancel
InTransit
    trackRide(trackingId)
    dropLocation
    cancel
PaymentPending
    confirmPayment
    //cancel functionality does not work
Completed
    collectReviewFeedBack()
        //cancel functionality does not work


UserProfileManagement
   - createProfile()
   - getPrfoile(id)
   - updateProfile(id)
   - deletProfile(id)

ProfileRepository
Map<String,User> profile = new HashMap<>();

DispacthService
  assignDriver(Locaion source);

RideTracker
-sourceLocation
-destinationLocation
-distanceToDestination//Harvesian formula
-ETA

TrackingService
generate(Location source ,Location destination)
update()
get(id)
delete(id)

LocarionProviders
-GMaps
-mapBox

LocationProvider

calculateDistance()
eta()

PaymentService
proceedPayment()
PaymentStrategy
  UPI
  Cash
ReviewService
 creatRevew()





