package lld.goodreads.model;

public class Pair {

    private String user;
    private int depth;

    public Pair(String user, int depth) {
        this.user = user;
        this.depth = depth;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }
}
