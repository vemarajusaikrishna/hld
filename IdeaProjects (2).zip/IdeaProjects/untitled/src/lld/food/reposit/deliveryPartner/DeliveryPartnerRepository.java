package lld.food.reposit.deliveryPartner;

import lld.food.model.DeliveryPartner;
import lld.food.model.Location;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class DeliveryPartnerRepository {

    private Map<String, DeliveryPartner> partnerMap = new HashMap<>();
    private TreeMap<Double,TreeMap<Double,String>> geoIndex = new TreeMap<>();


    public void addPartner(DeliveryPartner deliveryPartner){
        partnerMap.putIfAbsent(deliveryPartner.getId(),deliveryPartner);
        Location newLocation = deliveryPartner.getLocation();
        geoIndex.putIfAbsent(newLocation.getLatitude(),new TreeMap<>());
        geoIndex.get(newLocation.getLatitude()).put(newLocation.getLongitude(), deliveryPartner.getId());
    }

    public void removePartner(String deliveryPartnerId){
        partnerMap.remove(deliveryPartnerId);
    }

    public DeliveryPartner getPartner(String deliveryPartnerId){
        return  partnerMap.get(deliveryPartnerId);
    }

    public void updateLocation(Location newLocation,String deliveryPartnerId){

        Location oldLocation =  partnerMap.get(deliveryPartnerId).getLocation();
        geoIndex.get(oldLocation.getLatitude()).remove(oldLocation.getLongitude());
        geoIndex.putIfAbsent(newLocation.getLatitude(),new TreeMap<>());
        geoIndex.get(newLocation.getLatitude()).put(newLocation.getLongitude(), deliveryPartnerId);
    }

    public Location getLocation(String deliveryPartnerId){
       return  partnerMap.get(deliveryPartnerId).getLocation();
    }


}
