package chess;

import chess.model.enums.GameStatus;
import chess.model.piece.Pawn;
import chess.model.piece.Piece;
import chess.model.piece.Queen;
import chess.momento.MoveHistory;
import chess.momento.MoveMomento;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

public class Game {

    private Board board;
    private List<Player> players;
    private Player currentPlayer;
    private Player opponent;
    private Player winner;
    private GameStatus gameStatus;
    private MoveHistory moveHistory;

    public Game()
    {
        this.board = new Board();
        this.players = new ArrayList<>();
        this.moveHistory=new MoveHistory();
    }

    public boolean move(Cell source , Cell desintaion) {

        //retrieve piece in source cell
        Piece piece = board.getCell()[source.getX()][source.getY()].getPiece();

        //retrieve piece in target cell if any
        Piece capturedPiece = board.getCell()[desintaion.getX()][desintaion.getY()].getPiece();

        //check there is a piece in source location and that is of current player only
        //Pre-move check
        if(piece != null && currentPlayer.getPieceColour().equals(piece.getPieceColour())){
            System.out.println("There is no piece at source location or wrong player turn");
            return false;
        }

        //check if move is legal for this piece
        if(!piece.canMove(desintaion,board)){
            System.out.println("Move is not legal move for this piece");
            return false;
        }

        //simulate the move if it leaves the current players king in check
        board.getCell()[source.getX()][source.getY()].setPiece(null);
        board.getCell()[desintaion.getX()][desintaion.getY()].setPiece(piece);
        if(isKingInCheck(currentPlayer)){

            System.out.println("Invalid move : King would be in check.");
            return false;
        }
        //revert the move
        board.getCell()[source.getX()][source.getY()].setPiece(piece);
        board.getCell()[desintaion.getX()][desintaion.getY()].setPiece(capturedPiece);

        //capture the opponent
        if(capturedPiece != null)
        {
            capturedPiece.isKilled(true);
            System.out.println("Cpatured piece of name : " + capturedPiece.getClass().getSimpleName());

        }
        //capture the opponent
        if(capturedPiece != null)
        {
            capturedPiece.isKilled(true);
            System.out.println("Cpatured piece of name : " + capturedPiece.getClass().getSimpleName());

        }
        //finalize the move and also handle special moves if there are any
        pieceMoved(piece,desintaion);

        //check if the opponents king is in check and checkmate
        if(isKingInCheck(opponent)) {
            System.out.println("opponents king is in check.Now proceeding to verify if checkmate occurs");
            if (isCheckMate(opponent)) {
                System.out.println("opponents king is in checkMate");
            }
        }
        else {
            if(isStaleMate(opponent)){
                System.out.println("opponents king is in stalemate");
            }
        }

        //swith the player
        currentPlayer = opponent;
        moveHistory.saveMove(new MoveMomento("","",piece,capturedPiece));
        return true;
    }

    private boolean pieceMoved(Piece source, Cell desintaion) {
        //handle the pawn promotion if required
        int x = desintaion.getX();
        int y = desintaion.getY();
        if(source instanceof Pawn && ( y == 0 || y == 7) )
        {
            source = new Queen(currentPlayer.getPieceColour());
        }
        board.getCell()[x][y].setPiece(source);
        return true;

    }

    private boolean isKingInCheck(Player currentPlayer) {
        //provide logic to verify if king is in check
        return false;
    }

    private boolean isCheckMate(Player currentPlayer) {
        //provide logic to verify if king is in checkMate
        return false;
    }

    private boolean isStaleMate(Player currentPlayer) {
        //provide logic to verify if king is in checkMate
        return false;
    }

    public void reconstructGame(){

       Stack moveMomentoHistory = moveHistory.getMoveHistory();

       for(int i = moveMomentoHistory.size()-1; i >=0;i++){

       }
    }




}
