package other;

import java.util.Arrays;

public class MaxPossibleCharge {

    public static int maxRemainingCharge(int[] charge) {
        int N = charge.length;
        int[][] dp = new int[N][N];
        Arrays.fill(dp[0], -1);

        int res = maxCharge(charge, 0, N - 1, dp);

        return res;
    }

    public static int maxCharge(int[] charge, int left, int right, int[][] dp) {
        if (right <= left) return 0;

        if(dp[left][right] != -1) return dp[left][right];

        int res = 0;;
        for(int i = left; i <= right; i++) {
            int systemCharge = 0;
            if (i > 0) systemCharge += charge[i - 1];
            if (i < right) systemCharge += charge[i + 1];

            res = Math.max(systemCharge, maxCharge(charge, left, i - 1, dp) + maxCharge(charge, i + 1, right, dp));

            res = Math.max(res, systemCharge);
        }

        dp[left][right] = res;
        return res;
    }


    // Example Usage
    public static void main(String[] args) {
// int[] charge = {-3, 1, 4, -1, 5, -9};
// int[] charge = {-2, 4, 9, 1, -1};
// int[] charge = {-2, 4, 3, -2, 1};
        int[] charge = {-1, 3, 2};
        System.out.println("Maximum Possible Charge: " + maxRemainingCharge(charge));
    }
}
