package atm;

import java.util.HashMap;

public class TransactionMenuFactory {

    Map<Integer,TransactionType> transactionMap = new HashMap();

    public boolean addToMenu(int inputValue, Class<Tr> transactionType){
        transactionMap.put(inputValue,transactionType.for);
    }
}
