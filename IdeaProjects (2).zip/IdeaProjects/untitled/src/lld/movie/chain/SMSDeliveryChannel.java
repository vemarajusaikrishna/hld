package lld.movie.chain;

public class SMSDeliveryChannel extends DeliveryChannelHandler{
    public SMSDeliveryChannel(DeliveryChannelHandler deliveryChannelHandler) {
        super(deliveryChannelHandler);
    }

    @Override
    public void sendNotification(String message, User user) {

    }
}
