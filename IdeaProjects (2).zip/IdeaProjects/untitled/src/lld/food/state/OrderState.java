package lld.food.state;


import lld.food.model.Order;

public abstract class OrderState {
    protected Order order;

    public OrderState(Order order) {
        this.order = order;
    }

    public abstract boolean canAccept();
    public abstract boolean assignDeliveryPartner();
    public abstract boolean generateTrackingDetails();

    public abstract void generateOtp();
    public abstract void validateOtp();
    public abstract void getFeedbackAndRating();
}
