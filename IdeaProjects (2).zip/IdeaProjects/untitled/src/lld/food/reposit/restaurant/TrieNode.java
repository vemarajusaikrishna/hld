package lld.food.reposit.restaurant;

import lld.food.model.Restaurant;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrieNode {

    private Map<Character,TrieNode> children;
    private boolean isEndOfWord;
    private List<Integer> restaurants;

    public TrieNode() {
        this.children = new HashMap<>();
        this.restaurants = new ArrayList<>();
    }

    public void add(String[] names, Restaurant id){
        TreeNode
        for (String part :names ){

            for (char ch : part.toCharArray()){


            }
        }

    }
}
