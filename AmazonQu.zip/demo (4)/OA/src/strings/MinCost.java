package strings;

public class MinCost {

    public static int getMinRemovals(String password, String ref, int[] cost) {
        int[] mapPwd = new int[26];
        int[] mapRef = new int[26];

        for (int i=0;i<password.length();i++) {
            mapPwd[password.charAt(i) - 'a']++;
        }

        for (int i=0;i<ref.length();i++) {
            mapRef[ref.charAt(i) - 'a']++;
        }

        int result = Integer.MAX_VALUE;

        for (char c : ref.toCharArray()) {
            int num = c - 'a';
            if (mapPwd[num] >= mapRef[num]) {
                int extra = mapPwd[num] - mapRef[num] + 1;
                result =  Math.min(result, extra * cost[num]);
            }else{
                result = 0;
            }
        }
        return result == Integer.MAX_VALUE ? 0 : result;
    }
    public static void main(String ... args){

    }
}
