package lld.ratelimiter.decorator;

import lld.ratelimiter.algorithms.RalteLimiterAlgorithmFactory;
import lld.ratelimiter.algorithms.RateLimitingAlgorithm;

import java.net.http.HttpRequest;

public class RateLimter extends APIDecorator{
    private RalteLimiterAlgorithmFactory factory;
    public RateLimter(API api) {
        super(api);
    }
    @Override
    public void processRequest(String userId, HttpRequest httpRequest) {
       RateLimitingAlgorithm rateLimitingAlgorithm = factory.getRateLimiter("tokenBucket");
       if(rateLimitingAlgorithm.handleRequest(userId)){
           super.api.processRequest(userId, httpRequest);
       }
       System.out.println("Rate limiter rejected the request");
    }
}
