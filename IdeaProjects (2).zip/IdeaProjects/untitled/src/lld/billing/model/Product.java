package lld.billing.model;

public class Product {
}
