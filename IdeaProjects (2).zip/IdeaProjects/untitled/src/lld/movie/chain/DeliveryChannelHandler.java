package lld.movie.chain;

public abstract class DeliveryChannelHandler {

    protected DeliveryChannelHandler nextHandler;

    public DeliveryChannelHandler(DeliveryChannelHandler deliveryChannelHandler) {
        this.nextHandler = deliveryChannelHandler;
    }

    public abstract void sendNotification(String message,User user);
}
