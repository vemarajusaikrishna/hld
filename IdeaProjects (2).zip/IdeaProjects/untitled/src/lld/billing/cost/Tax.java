package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Location;
import lld.billing.model.Purchase;

import java.util.HashMap;
import java.util.Map;

public class Tax extends TotalCostDecorator{
    public Tax(TotalCost totalCost) {
        super(totalCost);
    }

    @Override
    public double calculateCost(Customer customer , Purchase purchase) {
        return totalCost.calculateCost(customer, purchase)+customer.getLocation().getTax();
    }
}
