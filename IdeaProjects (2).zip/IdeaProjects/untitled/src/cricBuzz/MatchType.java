package cricBuzz;

public interface MatchType {



}
