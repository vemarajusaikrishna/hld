package cricBuzz;

import cricBuzz.innings.Innings;

import java.time.LocalDateTime;

public class Match {

    private LocalDateTime matchDate;
    private String stadium;
    private MatchType matchType;
    private Innings[] innings;
    private Team teamA;
    private Team teamB;
    private Team tossWinner;


}
