package snake.state.player;

import snake.Player;

public class RollingDice extends PlayerState{
    @Override
    public void rollDice(Player player) {
       player.rollDice();
    }

    @Override
    public void move(Player player, int spaces) {
       System.out.println("cannot move while rolling dice");
    }

    @Override
    public void pause(Player player) {
       player.setPlayerState(new PauseState());
       player.pause();
    }

    @Override
    public void resume(Player player) {
        System.out.println(" Already game is in active");
    }

    @Override
    public void exitGame(Player player) {
        player.setPlayerState(new Exited());
        player.exit();
    }
}
