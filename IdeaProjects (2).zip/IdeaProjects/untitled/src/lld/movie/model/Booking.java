package lld.movie.model;

import lld.movie.state.BookingState;
import lld.movie.state.Idle;

import java.time.LocalDateTime;

public class Booking {

    private String bookingId;
    private LocalDateTime bookedOn;
    private LocalDateTime updatedOn;
    private User bookedBy;
    private String  showId;
    private int tickets;
    private BookingState state;

    public Booking() {
        this.state = new Idle();
    }


}
