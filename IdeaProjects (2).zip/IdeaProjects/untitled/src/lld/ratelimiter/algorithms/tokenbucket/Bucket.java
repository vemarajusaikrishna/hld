package lld.ratelimiter.algorithms.tokenbucket;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class Bucket {

  private int capacity;
  private AtomicInteger remainingTokens ;
  private int refillRatePerSecond;
  private int burstWindow ;
  private ScheduledExecutorService scheduledExecutorService;

    public Bucket(int refillRatePerSecond, int burstWindow) {
        this.refillRatePerSecond = refillRatePerSecond;
        this.burstWindow = burstWindow;
        this.capacity = refillRatePerSecond*burstWindow;
        this.remainingTokens = new AtomicInteger(capacity);
        this.scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();
        this.scheduledExecutorService.scheduleAtFixedRate(this :: refillTokens,0,1, TimeUnit.SECONDS);
    }

    public boolean isAllowed(){
      //overhead of checking refill requirement is removed for each requireme
        //refill logic is decoupled from request execution
            if(remainingTokens.get() > 0){
                remainingTokens.decrementAndGet();
                return true;
            }
        return false;

    }

    private void refillTokens(){
        //check if overflow
            remainingTokens.set(Math.min(refillRatePerSecond+remainingTokens.get(),capacity));
            System.out.println("Bucket is refilled successfully");
    }
}
