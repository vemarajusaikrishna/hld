package lld.ratelimiter;

import lld.ratelimiter.decorator.API;
import lld.ratelimiter.decorator.ConcreteAPI;
import lld.ratelimiter.decorator.Logging;
import lld.ratelimiter.decorator.RateLimter;

public class Driver {

    public static void main(String ... args){
      API api =  new Logging(new RateLimter(new ConcreteAPI()));
      api.processRequest("12345",null);
    }
}
