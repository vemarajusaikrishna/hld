package parkingLot.model;

public class Bill {
}
