package lld.food.state;

import lld.food.model.Order;

public class PreparingState extends OrderState {
    public PreparingState(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        return false;
    }

    @Override
    public boolean assignDeliveryPartner() {
        //assign delivery partner and change the state;
        //move to outForDelivery based on restaurant confirmation.
        return true;
    }

    @Override
    public boolean generateTrackingDetails() {
        return false;
    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {

    }

    @Override
    public void getFeedbackAndRating() {

    }
}
