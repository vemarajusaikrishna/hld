package lld.ride.model;

public class Vehicle {

    private String number;
    private String name;
    private String modelNumber;
    private String vehicleType;
}
