package atm.states;

import atm.ATM;

public class CardEjection extends State {
    public CardEjection(ATM atm) {
        super(atm);
    }

    @Override
    public void insertCard() {

    }

    @Override
    public void validateCard() {
        //read card using card reader slot
        //send the card details to ATM internal system for validation against bank.

    }

    @Override
    public void validatePin() {
        //read the pin from keyboard
        //use ATM internal machine for validation
    }

    @Override
    public void ejectCard() {

    }


}
