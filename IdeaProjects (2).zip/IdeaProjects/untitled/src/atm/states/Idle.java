package atm.states;

import atm.ATM;
import atm.Card;

public class Idle extends State {
    public Idle(ATM atm) {
        super(atm);
    }

    @Override
    public void readAndValidateCard() {
        System.out.println("Operation does not support.");
    }

    @Override
    public void readAndValidatePin() {
        System.out.println("Operation does not support.");
    }

    @Override
    public void ejectCard() {
        System.out.println("Operation does not support.");
    }

    @Override
    public void displayError() {
        System.out.println("Operation does not support.");
    }

    @Override
    public void insertCard(Card card) {
        System.out.println("Please enter the card.");
        atm.
        atm.setInsertedCard(card);
        atm.setState(new CardInserted(atm));
    }

}
