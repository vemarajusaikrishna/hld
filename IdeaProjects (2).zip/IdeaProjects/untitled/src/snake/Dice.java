package snake;

import java.util.concurrent.ThreadLocalRandom;

public class Dice {
    private int dice;
    private int min =1;
    private int max =6;

    public int getDice() {
        return dice;
    }

    public void setDice(int dice,int min,int max) {
        this.dice = dice;
        this.min=min;
        this.max=max;
    }

    public Dice(int dice) {
        this.dice = dice;
    }

    public int rollDice()
    {
        int total =0;
        for(int i =0 ; i < dice ;i++)
        {
            total += ThreadLocalRandom.current().nextInt(min,max+1);
        }
        return total;
    }
}
