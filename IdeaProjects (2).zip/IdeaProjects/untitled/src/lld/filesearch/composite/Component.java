package lld.filesearch.composite;

import java.util.List;

public abstract class Component {
   private String name;
   private String extension;
   private long size;
   private List<Component> children;

    public Component(String name, String extension, long size, List<Component> children) {
        this.name = name;
        this.extension = extension;
        this.size = size;
        this.children = children;
    }

    public String getName() {
        return name;
    }

    public String getExtension() {
        return extension;
    }

    public List<Component> getChildren() {
        return children;
    }

    public long getSize() {
        int size =0;
        if(children == null){
            return size;
        }
        for(Component component : children){
            size += component.getSize();
        }
        return size;
    }
}
