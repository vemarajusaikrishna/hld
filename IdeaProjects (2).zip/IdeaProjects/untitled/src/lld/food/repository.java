package lld.food;

public class repository {
}
