package parkingLot.floor;

import parkingLot.model.ParkingSlot;
import parkingLot.slot.ParkingSlotManager;

import java.util.HashMap;
import java.util.Map;

public class ParkingFloorManager {

    private Map<ParkingSlot, ParkingSlotManager> slotMangers = new HashMap<>();

    public boolean register(ParkingSlot parkingSize,Class<ParkingSlotManager> parkingSlot)
    {
        try {
            slotMangers.put(parkingSize,parkingSlot.newInstance());
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        return true;
    }

    public boolean deRegister(ParkingSlot parkingSize)
    {
        slotMangers.remove(parkingSize);
        return true;
    }
    public ParkingSlotManager getSlotManager(ParkingSlot parkingSize) {
        if(slotMangers.containsKey(parkingSize))
            return slotMangers.get(parkingSize);
        return null;
    }
}
