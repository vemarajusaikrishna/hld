package cricBuzz.score.card;

public class BowlingScoreCard {

    private int ballsThrows;
    private int runsGiven;
    private int noBalls;
    private int wideBalls;

}
