package lld.ratelimiter.algorithms.leakyBucket;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class LeakyBucket {

    private AtomicInteger currentWater;
    private int leakRatePerSecond;
    private int capacity;
    private ScheduledExecutorService executorService = Executors.newSingleThreadScheduledExecutor();

    public LeakyBucket( int leakRatePerSecond, int burstWindow) {
        this.leakRatePerSecond = leakRatePerSecond;
        this.capacity = this.leakRatePerSecond*burstWindow;
        this.currentWater = new AtomicInteger(0);
        executorService.scheduleAtFixedRate(this :: leakWater,0,leakRatePerSecond, TimeUnit.SECONDS);
    }

    public boolean isAllowed(){
          //add request
          if(currentWater.get() < capacity){
               currentWater.incrementAndGet();
               return true;
          }
      return false;
    }

    private void leakWater() {
             int waterAfterLeakage = Math.max(0, currentWater.get() -leakRatePerSecond);
             currentWater.set(waterAfterLeakage);
        }


}
