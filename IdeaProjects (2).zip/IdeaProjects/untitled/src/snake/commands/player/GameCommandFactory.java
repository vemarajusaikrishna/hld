package snake.commands.player;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class GameCommandFactory {

    Map<Integer, GameCommand> commandFactory = new HashMap<>();

    public void registerCommand(int input,Class<? extends GameCommand> command ) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        commandFactory.put(input,command.getDeclaredConstructor().newInstance());
    }

    public GameCommand removeCommand(int input) {
       return  commandFactory.remove(input);
    }

    public GameCommand getCommand(int input) {
        return  commandFactory.getOrDefault(input,null);
    }



}
