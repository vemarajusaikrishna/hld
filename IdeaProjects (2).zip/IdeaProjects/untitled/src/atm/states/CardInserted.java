package atm.states;

import atm.ATM;
import atm.Card;

public class CardInserted extends State {
    public CardInserted(ATM atm) {
        super(atm);
    }

    @Override
    public void insertCard() {
        System.out.println("Card already inserted in slot.");
    }


    @Override
    public void readAndValidateCard() {
        atm.getDisplay().writeToDisplay("Card reading initiated.....");
        Card card =  atm.getCardReader().acceptCard();
        if(atm.getCardReader().readCard(card)) {
            atm.setInsertedCard(card);
            if(atm.validateCard()) {
                atm.getDisplay().writeToDisplay("Card validation initiated.....");
            }
            else{
                atm.setInsertedCard(null);
                atm.setState(new ErrorState(atm));
            }
        }
        else {
            atm.setState(new ErrorState(atm));
        }

    }

    @Override
    public void readAndValidatePin() {
        atm.getDisplay().writeToDisplay("operation not supported");
    }


    @Override
    public void ejectCard() {
        atm.getDisplay().writeToDisplay("operation not supported");
    }

    @Override
    public void displayError() {
        atm.getDisplay().writeToDisplay("operation not supported");
    }
}
