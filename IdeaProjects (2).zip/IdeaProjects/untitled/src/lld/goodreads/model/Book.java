package lld.goodreads.model;

import java.util.UUID;

public class Book {

    private String bookId;
    private String bookTitle;

    public Book(){
        this.bookId = UUID.randomUUID().toString();
    }
    public String getBookId() {
        return bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public Book(String bookId) {
        this.bookId = bookId;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }
}
