package lld.ride.repository;

import lld.ride.model.RideTracker;

import java.util.HashMap;
import java.util.Map;

public class TrackingRepository {

    private Map<String, RideTracker> trackerMap = new HashMap();

    public void addTracker(RideTracker rideTracker){
         trackerMap.put(rideTracker.getTrackerId(), rideTracker);
    }

    public RideTracker getTracker(String trackerId){
     return   trackerMap.get(trackerId);
    }

    public RideTracker removeTracker(String trackerId){
        return  trackerMap.remove(trackerId);
    }

}
