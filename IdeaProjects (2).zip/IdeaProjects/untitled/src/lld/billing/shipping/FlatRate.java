package lld.billing.shipping;

import lld.billing.model.Purchase;

public class FlatRate extends ShippingCostHandler {

    private double shippingCost;

    public FlatRate(double shippingCost) {
        this.shippingCost = shippingCost;
    }

    @Override
    public double getShippingCost(Purchase purchase) {

    }
}
