package lld.movie.state;

public class PaymentPending {

    //proceeds payment,if success confirmed state.
    //if failed,retry 3 times and ,go to failed state
}
