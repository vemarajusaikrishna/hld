package chess.model.piece;

import chess.model.enums.PieceColour;
import chess.Board;
import chess.Cell;

import java.util.List;

public class Pawn extends Piece{
    public Pawn(PieceColour pieceColour) {
        super(pieceColour);
    }

    @Override
    public boolean canMove(Cell target, Board board) {
        return false;
    }

    @Override
    public List<int[]> getLegalMoves(Cell target, Board board) {
        return List.of();
    }
}
