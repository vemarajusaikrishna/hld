package lld.movie.state;

public class SeatSelection {

    //user selects seat by applying lock
}
