package lld.ratelimiter.decorator;

public abstract class APIDecorator implements API {

    protected API api;

    public APIDecorator(API api) {
        this.api = api;
    }
}
