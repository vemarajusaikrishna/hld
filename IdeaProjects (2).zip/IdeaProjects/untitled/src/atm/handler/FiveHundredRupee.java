package atm.handler;

public class FiveHundredRupee extends DenominationHandler {


}
