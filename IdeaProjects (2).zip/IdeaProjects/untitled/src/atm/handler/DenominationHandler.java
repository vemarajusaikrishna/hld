package atm.handler;

import atm.CashStorageBox;

public abstract class DenominationHandler {
    private DenominationHandler nextHandler;
    private CashStorageBox cashStorageBox;

    public DenominationHandler getNextHandler() {
        return nextHandler;
    }

    public void setNextHandler(DenominationHandler nextHandler) {
        this.nextHandler = nextHandler;
    }

    public CashStorageBox getCashStorageBox() {
        return cashStorageBox;
    }

    public void setCashStorageBox(CashStorageBox cashStorageBox) {
        this.cashStorageBox = cashStorageBox;
    }
}
