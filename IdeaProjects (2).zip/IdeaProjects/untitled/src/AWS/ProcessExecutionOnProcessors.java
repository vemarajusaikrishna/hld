package AWS;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ProcessExecutionOnProcessors {


    public static int lowerBound(List<Integer> arr, int target) {
        int left = 0, right = arr.size() - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (arr.get(mid) < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return left;
    }

    public static int upperBound(List<Integer> arr, int target) {
        int left = 0, right = arr.size() - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (arr.get(mid) <= target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return left;
    }

    public static List<List<Integer>> solve(List<Integer> power, List<Integer> minPower, List<Integer> maxPower) {
        int n = minPower.size();
        List<List<Integer>> res = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            res.add(new ArrayList<>());
        }

        Collections.sort(power);
        List<Long> prefix = new ArrayList<>(power.size() + 1);
        prefix.add(0L);

        // Calculate prefix sum
        for (int i = 1; i <= power.size(); i++) {
            prefix.add(prefix.get(i-1) + power.get(i-1));
        }

        // for each process i, find using binary search the lower and upper bounds.
        // then append the amount of processes with the sum of them using the prefix array.
        for (int i = 0; i < n; i++) {
            int left = lowerBound(power, minPower.get(i));
            int right = upperBound(power, maxPower.get(i));

            if (right >= left) {
                res.get(i).add(right - left);
                res.get(i).add((int)(prefix.get(right) - prefix.get(left)));
            } else {
                res.get(i).add(0);
                res.get(i).add(0);
            }
        }

        return res;
    }

    public static void main(String[] args) {
        List<Integer> power = Arrays.asList(11, 11, 11);
        List<Integer> minPower = Arrays.asList(8, 13);
        List<Integer> maxPower = Arrays.asList(11, 100);
        List<List<Integer>> res = solve(power, minPower, maxPower);

        for (List<Integer> r : res) {
            System.out.println(r.get(0) + " " + r.get(1));
        }
    }
}
