package lld.food.model;

import java.util.ArrayList;
import java.util.List;

public class Menu {

    private List<Section> sections;

    public Menu() {
        this.sections = new ArrayList<>();
    }

    public List<Section> getSections() {
        return sections;
    }

    public void addSections(List<Section> sections) {
        this.sections.addAll(sections);
    }
}
