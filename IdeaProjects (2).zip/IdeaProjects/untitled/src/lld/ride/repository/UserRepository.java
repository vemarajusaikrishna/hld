package lld.ride.repository;

import lld.ride.model.Driver;
import lld.ride.model.User;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {

    private Map<String, User> driverProfileRepository = new HashMap();

    public void addDriver(Driver driver){
         driverProfileRepository.put(driver.getId(),driver);
    }
    //update
    //remove
    //get
}
