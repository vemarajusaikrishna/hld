package lld.movie.state;

public interface BookingState {

    public void searchMovie();
    public void selectSeat();
    public void proceedPayment();
    public void cancel(String bookingId);
    public void collectReviewAndRating();


}
