package chess;

import chess.model.enums.PieceColour;
import chess.model.piece.Piece;

import javax.swing.text.Position;

public abstract class BoardListener  {

   public void  onPieceMoved(Cell source, Cell target, Piece movedPiece);
    void onPieceCaptured(Cell cell,Piece captured,Piece capturer);
    void onCheck(Position kingPosition, PieceColour pieceColour);
    void onCheckMate(PieceColour colour);
    void onStalemate();
}
