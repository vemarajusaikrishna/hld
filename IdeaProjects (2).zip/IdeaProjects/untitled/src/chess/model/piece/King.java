package chess.model.piece;

public class King {
}
