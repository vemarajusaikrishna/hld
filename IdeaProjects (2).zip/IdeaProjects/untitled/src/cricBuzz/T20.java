package cricBuzz;

public class T20 {
}
