package lld.ratelimiter.decorator;

import java.net.http.HttpRequest;

public class Logging extends APIDecorator{
    public Logging(API api) {
        super(api);
    }

    @Override
    public void processRequest(String userId, HttpRequest httpRequest) {
        System.out.println("Request is logging now");
        api.processRequest(userId,httpRequest);
    }
}
