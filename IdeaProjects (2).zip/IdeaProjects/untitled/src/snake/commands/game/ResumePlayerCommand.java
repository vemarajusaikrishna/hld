package snake.commands.game;

import snake.Player;

public class ResumePlayerCommand extends PlayerCommand {
    @Override
    public void execute(Player player) {
         player.resume();
    }

}
