package atm.handler;

public class TwoHundredRupee extends DenominationHandler{

}
