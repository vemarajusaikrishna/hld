package lld.movie.factory;

public class CardPayment {
}
