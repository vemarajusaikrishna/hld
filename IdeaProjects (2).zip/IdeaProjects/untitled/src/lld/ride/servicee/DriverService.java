package lld.ride.servicee;

public class DriverService {

    public void acceptRide(){

    }

   public void cancelRide(){

   }

   public void getTotalEarnings(){

   }
   public void
}
