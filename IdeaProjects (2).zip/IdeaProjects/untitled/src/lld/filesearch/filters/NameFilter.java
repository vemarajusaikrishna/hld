package lld.filesearch.filters;

import lld.filesearch.composite.Component;

public class NameFilter implements Specification<Component>{

    private String name;

    public NameFilter(String name) {
        this.name = name;
    }

    @Override
    public boolean isSatisfiedBy(Component item) {
        return (item.getName().equals(name));
    }
}
