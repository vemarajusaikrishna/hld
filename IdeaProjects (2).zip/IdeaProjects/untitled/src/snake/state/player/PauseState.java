package snake.state.player;

import snake.Player;

public class PauseState extends PlayerState {

    @Override
    public void rollDice(Player player) {
        System.out.println("Cannot roll dice,when game is paused.");
    }

    @Override
    public void move(Player player, int spaces) {
        System.out.println("Cannot move,when game is paused.");
    }

    @Override
    public void pause(Player player) {
        System.out.println("game is already paused.");
    }

    @Override
    public void resume(Player player) {
         player.setPlayerState(new Idle());
    }

    @Override
    public void exitGame(Player player) {
        player.setPlayerState(new Exited());
    }
}
