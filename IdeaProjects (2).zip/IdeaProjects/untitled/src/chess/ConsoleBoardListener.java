package chess;

import chess.model.enums.PieceColour;
import chess.model.piece.Piece;

import javax.swing.text.Position;

public class ConsoleBoardListener implements BoardListener{

    @Override
    public void onPieceMoved(Cell source, Cell target, Piece movedPiece) {
    }

    @Override
    public void onPieceCaptured(Cell cell, Piece captured, Piece capturer) {

    }

    @Override
    public void onCheck(Position kingPosition, PieceColour pieceColour) {

    }

    @Override
    public void onCheckMate(PieceColour colour) {

    }

    @Override
    public void onStalemate() {

    }
}
