package lld.movie.event;

public interface EventHandler {

    public void handle(Event event);
}
