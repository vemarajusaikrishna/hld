package arrays;

import java.util.*;

public class MaxLessThanEqualCapMin {


    private static int minimumRemovals(int capacity, int[] nums)
    {

        //count occurence of each element;
        Map<Integer,Integer> map = new HashMap();

        for(int num : nums)
        {
            map.put(num, map.getOrDefault(num,0)+1);
        }

        //calculate prefix sum
        int sum =0;
        for(int key : map.keySet())
        {
           sum += map.get(key);
           map.put(key,sum);
        }

        //find the elements in the range
        int max = 0;
        int prev =0;
        for(int num : map.keySet())
        {

            int x = num;
            int y = capacity * num;

            List<Integer> keyList = new ArrayList(map.keySet());
            int index = Collections.binarySearch(keyList,y);
            int pos = index >=0 ?index : -(index +1)-1;
            Integer itr = pos >= 0 ? map.get(keyList.get(pos)): null;

            int cur = (itr == null ?0:itr)-prev;
            max = Math.max(max,cur);
            prev = map.get(num);

        }

        return nums.length - max;

    }
    public static void main(String[] args) {
        int[] arr = { 1, 2,2,2, 3,3,3, 4, 4, 4, 5,5,5, 6, 6,6 };
        System.out.println(minimumRemovals(2, arr));
    }
}
