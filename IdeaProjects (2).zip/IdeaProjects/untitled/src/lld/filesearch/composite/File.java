package lld.filesearch.composite;

public class File extends Component {

    public File(String name, String extension, long size) {
        super(name, extension, size, null);
    }
}
