package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public interface TotalCost {


    double calculateCost(Customer customer, Purchase purchase);
}
