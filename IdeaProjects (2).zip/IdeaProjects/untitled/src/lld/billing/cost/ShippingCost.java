package lld.billing.cost;

import lld.billing.model.Customer;
import lld.billing.model.Purchase;

public class ShippingCost extends TotalCostDecorator{
    private double shippingCost;
    public ShippingCost(TotalCost totalCost, double shippingCost) {
        super(totalCost);
        this.shippingCost = shippingCost;
    }


    @Override
    public double calculateCost(Customer customer, Purchase purchase) {

        return totalCost.calculateCost(customer,purchase)+shippingCost;
    }
}
