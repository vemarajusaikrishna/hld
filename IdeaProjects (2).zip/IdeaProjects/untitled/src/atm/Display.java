package atm;

import java.util.Scanner;

public class Display {

    public void writeToDisplay(String result) {
        System.out.println("Writing out to screen : ");
        System.out.println(result);
    }
}
