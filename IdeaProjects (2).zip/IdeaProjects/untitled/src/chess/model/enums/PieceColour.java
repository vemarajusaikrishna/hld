package chess.model.enums;

public enum PieceColour {

    BLACK,
    WHITE;
}
