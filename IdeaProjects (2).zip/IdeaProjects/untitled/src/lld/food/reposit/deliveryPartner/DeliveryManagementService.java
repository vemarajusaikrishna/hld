package lld.food.reposit.deliveryPartner;

import lld.food.model.DeliveryConfiguration;
import lld.food.model.DeliveryPartner;
import lld.food.model.DeliveryTracker;
import lld.food.model.Location;
import lld.food.reposit.deliveryPartner.handler.HighSuccessrateAndRating;
import lld.food.reposit.deliveryPartner.handler.LeastTotalETA;
import lld.food.reposit.deliveryPartner.handler.LeastWorkLoad;
import lld.food.reposit.deliveryPartner.handler.OptimalDeliveryPartnerHandler;

import java.util.List;
import java.util.TreeMap;

public class DeliveryManagementService {
    private DeliveryPartnerRepository deliveryPartnerRepository;
    private DeliveryTrackerRepository deliveryTrackerRepository;
    private OptimalDeliveryPartnerHandler handler;

    public DeliveryManagementService() {
        this.deliveryPartnerRepository = new DeliveryPartnerRepository();
        this.deliveryTrackerRepository = new DeliveryTrackerRepository();
        this.handler = new LeastTotalETA(new LeastWorkLoad(new HighSuccessrateAndRating(null)));
    }

    public void assignDeliveryPartner(Location restaurantLocation,String orderId){
        //fetch delivery partners in availability status in 5 km radius to restaurant
        //use handler to obtain score
        //ask each one to in precedence to score
    }
    public DeliveryPartner getDeliveryPartner(String orderId){
        return null;
    }
    public void remove(String partnerId){

    }

    public void addPartner(DeliveryPartner deliveryPartner){

    }

    public DeliveryTracker getOrderLocation(String orderId){
           return null;
    }

    public void updateOrderLocation(String orderId,Location location){

    }

}
