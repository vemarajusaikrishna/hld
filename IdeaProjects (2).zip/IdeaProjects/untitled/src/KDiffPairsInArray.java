public class KDiffPairsInArray {

    //K-diff Pairs in an Array//https://leetcode.com/problems/k-diff-pairs-in-an-array/description/
}
