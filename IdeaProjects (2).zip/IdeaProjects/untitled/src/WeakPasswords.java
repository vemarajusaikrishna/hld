public class WeakPasswords {

    //https://leetcode.com/discuss/interview-question/4749861/Amazon-OA
}
