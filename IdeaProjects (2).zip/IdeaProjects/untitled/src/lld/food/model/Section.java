package lld.food.model;

import java.util.List;
import java.util.Map;

public class Section {

    private String name;
    Map<Integer,FoodItem> foodItems;
}
