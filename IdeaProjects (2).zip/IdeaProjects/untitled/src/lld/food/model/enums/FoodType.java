package lld.food.model.enums;

public enum FoodType {
    VEGETARIAN,
    NON_VEGETARIAN;
}
