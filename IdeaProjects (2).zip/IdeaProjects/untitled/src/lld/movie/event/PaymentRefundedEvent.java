package lld.movie.event;

public class PaymentRefundedEvent implements Event{
    @Override
    public String eventType() {
        return "";
    }

    @Override
    public String payload() {
        return "";
    }
}
