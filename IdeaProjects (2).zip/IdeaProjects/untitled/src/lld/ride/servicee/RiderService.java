package lld.ride.servicee;

import lld.ride.model.Location;

public class RiderService {

    public String requestRide(Location pickup, Location dropOff, String userId){

    }

    public void cancelRide(String rideId){

    }
    
    public void trackRide(String rideId){

    }

    public void updateLocation(){

    }

    public void reviewAndRate(String rideId,Review review){

    }

    public double getEstimatedFare(){

    }
}
