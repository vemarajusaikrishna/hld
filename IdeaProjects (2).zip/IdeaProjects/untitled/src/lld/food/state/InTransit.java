package lld.food.state;

import lld.billing.model.Order;

public class InTransit extends OrderState {
    public InTransit(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        return false;
    }

    @Override
    public boolean assignDeliveryPartner() {
    }

    @Override
    public boolean generateTrackingDetails() {
        //update eta at regular intervals and real time of tracking of driver.
        return false;
    }

    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {
         //once otp is given to driver in this state,order delivered successfully
         //state transition to delivered.
    }


    @Override
    public void getFeedbackAndRating() {

    }
}
