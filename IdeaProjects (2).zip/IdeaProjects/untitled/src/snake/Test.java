package snake;

public class Test {


    public static void main(String[] args)
    {
        SnakeAndLadder snakeAndLadder= new SnakeAndLadder(15,16,10,1);
        snakeAndLadder.startGame();

    }

}
