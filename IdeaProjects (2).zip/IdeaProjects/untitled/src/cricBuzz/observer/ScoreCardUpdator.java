package cricBuzz.observer;

public interface ScoreCardUpdator {
}
