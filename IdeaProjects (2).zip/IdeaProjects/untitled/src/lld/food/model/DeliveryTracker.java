package lld.food.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class DeliveryTracker {

    private String orderId;
    private double distanceToDestination;
    private LocalTime eta;
    private Location currentLocation;
    private Location destination;
    private String deliveryPartnerId;
    private boolean isCompleted;

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public double getDistanceToDestination() {
        return distanceToDestination;
    }

    public void setDistanceToDestination(double distanceToDestination) {
        this.distanceToDestination = distanceToDestination;
    }

    public LocalTime getEta() {
        return eta;
    }

    public void setEta(LocalTime eta) {
        this.eta = eta;
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Location currentLocation) {
        this.currentLocation = currentLocation;
    }

    public Location getDestination() {
        return destination;
    }

    public void setDestination(Location destination) {
        this.destination = destination;
    }

    public String getDeliveryPartnerId() {
        return deliveryPartnerId;
    }

    public void setDeliveryPartnerId(String deliveryPartnerId) {
        this.deliveryPartnerId = deliveryPartnerId;
    }

    public void updateLocation(Location partnerLocation){
        calculateEta(partnerLocation);
        notifyCustomer();
        this.currentLocation = partnerLocation;

    }

    private void notifyCustomer() {
    }

    private void calculateEta(Location partnerLocation) {
        double speed =  calculateSpeed(partnerLocation);
        distanceToDestination = currentLocation.calculateDistance(currentLocation,destination);
        this.eta = LocalTime.now().plusMinutes((long)(distanceToDestination/speed)*60);
    }

    private double calculateSpeed(Location partnerLocation){
        double distance = currentLocation.calculateDistance(currentLocation,partnerLocation);
        Duration duration = Duration.between(partnerLocation.getTimestamp(), currentLocation.getTimestamp());
        double hours = duration.toSeconds()/3600.0;
        return distance/hours;
    }
}
