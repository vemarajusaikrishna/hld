package lld.billing.model.productcategory;

public class Cloths extends ProductCategory{
}
