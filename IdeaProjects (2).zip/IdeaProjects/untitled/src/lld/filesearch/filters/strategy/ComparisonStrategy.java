package lld.filesearch.filters.strategy;

public interface ComparisonStrategy {

    boolean compare(long given, long actual);
}

