package snake;

import java.util.HashMap;
import java.util.Map;

public class Board1 {

    private int finalPosition;
    private Map<Integer,Integer> snakes;
    private Map<Integer,Integer> ladders;

    public Board1(int finalPosition) {
        this.snakes = new HashMap<>();
        this.ladders = new HashMap();
        this.finalPosition = finalPosition;
    }

    public void addSnake(int start , int end){
        snakes.put(start,end);
    }

    public void addLadder(int start , int end){
        ladders.put(start,end);
    }

    public int getFinalPosition(){
        return finalPosition;
    }

    public int getLandingPosition(int position){
        if(ladders.containsKey(position)){

        System.out.println("Landed on a ladder");
        return ladders.get(position);

        }
        else if(snakes.containsKey(position)) {
          return snakes.get(position);
        }
        return position;
    }

    public void setFinalPosition(int finalPosition) {
        this.finalPosition = finalPosition;
    }
}
