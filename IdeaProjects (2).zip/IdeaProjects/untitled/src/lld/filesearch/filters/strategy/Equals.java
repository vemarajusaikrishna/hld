package lld.filesearch.filters.strategy;

public class Equals implements ComparisonStrategy {
    @Override
    public boolean compare(long given, long actual) {
        return given == actual;
    }
}
