package parkingLot;

public class ParkingLotTest {

    public static void main(String... args)
    {

        Thread entranceGate1 = new Thread(new EntranceGate(1),"EntranceGate1");
        Thread entranceGate2 = new Thread(new EntranceGate(2),"EntranceGate2");
        Thread entranceGate3 = new Thread(new EntranceGate(3),"EntranceGate3");

        entranceGate1.start();
        entranceGate2.start();
        entranceGate3.start();

        try
        {
            entranceGate1.join();
            entranceGate1.join();
            entranceGate1.join();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }
}
