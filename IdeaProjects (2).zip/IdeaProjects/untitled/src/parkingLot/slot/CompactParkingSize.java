package parkingLot.slot;

import parkingLot.model.ParkingSlot;

import java.util.List;
import java.util.Map;

public class CompactParkingSize extends ParkingSlotManager{

    public CompactParkingSize(Map<Integer, ParkingSlot> availableSpots, Map<Integer, ParkingSlot> occupied, ParkingStrategy parkingStrategy) {
        super(availableSpots, occupied, parkingStrategy);
    }
}
