package cricBuzz.innings;

import java.util.List;

public class Over {

    private int overNumber;
    private List<Ball> balls;

    public  void startOver()
    {

    }
}
