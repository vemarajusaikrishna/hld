package lld.movie.factory;

import lld.movie.model.PaymentInput;

public interface PaymentMethod {

    public boolean proceedPayment(PaymentInput input);
    public boolean refund(String transactionId);
}
