package lld.billing.model.productcategory;

import lld.billing.discounts.ProductCategory;

public class Electronics extends ProductCategory {
}
