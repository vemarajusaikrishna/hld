package snake.state.game;

import snake.Game;

public class InitializeState implements GameState {

    @Override
    public void initialize(Game game) {

        System.out.println("Game initialization started.");
        game.initialize();
        System.out.println("Game initialization completed");
        game.setGameState(new ActiveState());
        game.start();
    }

    @Override
    public void pause(Game game) {
        System.out.println("Please wait until the initialization is completed.");
    }

    @Override
    public void resume(Game game) {
        System.out.println("Please wait until the initialization is completed.");
    }

    @Override
    public void stop(Game game) {
        System.out.println("Please wait until the initialization is completed.");
    }

    @Override
    public void reset(Game game) {
        System.out.println("Please wait until the initialization is completed.");
    }

    @Override
    public void start(Game game) {
        System.out.println("Please wait until the initialization is completed.");
    }
}
