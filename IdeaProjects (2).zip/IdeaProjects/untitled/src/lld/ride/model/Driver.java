package lld.ride.model;

public class Driver extends User{

    private Vehicle vehicle;
}
