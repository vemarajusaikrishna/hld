package lld.food.state;

import lld.billing.model.Order;

public class Delivered extends OrderState{
    public Delivered(Order order) {
        super(order);
    }

    @Override
    public boolean canAccept() {
        return false;
    }

    @Override
    public boolean assignDeliveryPartner() {
        return false;
    }

    @Override
    public boolean generateTrackingDetails() {
        return false;
    }


    @Override
    public void generateOtp() {

    }

    @Override
    public void validateOtp() {

    }

    @Override
    public void getFeedbackAndRating() {
        //rating and feedback collected in delivered state and once customer provides it,them
        //order state changes to completed.

    }
}
