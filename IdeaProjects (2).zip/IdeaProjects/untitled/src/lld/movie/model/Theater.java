package lld.movie.model;

import lld.ride.model.Address;
import lld.ride.model.Location;

import java.time.LocalTime;

public class Theater {

    private String theatreId;
    private String name;
    private String description;
    private Address address;
    private Location location;
    private LocalTime openingTime;
    private LocalTime closingTime;

}
