package lld.ratelimiter.algorithms;

import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

public class RalteLimiterAlgorithmFactory {

    private Map<String, RateLimitingAlgorithm> algorithmMap = new HashMap<>();
    private static RalteLimiterAlgorithmFactory ralteLimiterAlgorithmFactory = null;

    public static RalteLimiterAlgorithmFactory getInstance(){
        if(ralteLimiterAlgorithmFactory == null){
            ralteLimiterAlgorithmFactory = new RalteLimiterAlgorithmFactory();
        }
        return ralteLimiterAlgorithmFactory;
    }

    public void register(String input, Class<? extends RateLimitingAlgorithm> ratelimiter) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {

        algorithmMap.putIfAbsent(input, ratelimiter.getDeclaredConstructor().newInstance());
    }

    public RateLimitingAlgorithm getRateLimiter(String input) {

       return algorithmMap.get(input);
    }

    public void deRegister(String input) {

         algorithmMap.remove(input);
    }
}