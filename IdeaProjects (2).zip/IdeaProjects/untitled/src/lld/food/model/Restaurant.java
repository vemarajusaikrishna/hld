package lld.food.model;

import lld.food.model.cuisine.Cuisine;

import java.time.LocalTime;
import java.util.Map;

public class Restaurant {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public LocalTime getOpeningTime() {
        return openingTime;
    }

    public void setOpeningTime(LocalTime openingTime) {
        this.openingTime = openingTime;
    }

    public LocalTime getClosingTime() {
        return closingTime;
    }

    public void setClosingTime(LocalTime closingTime) {
        this.closingTime = closingTime;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Map<Cuisine, Menu> getMenuCards() {
        return menuCards;
    }

    public void setMenuCards(Map<Cuisine, Menu> menuCards) {
        this.menuCards = menuCards;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    private int id;
    private String name;
    private String description;
    private String title;
    private float rating;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private Location location;
    private Address address;
    private Map<Cuisine,Menu> menuCards;


}
